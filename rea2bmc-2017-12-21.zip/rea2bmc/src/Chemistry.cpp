#include "Chemistry.h"
#include "operators.h"
#include "stdio.h"
#include "stdlib.h"
#include "fun.h"

#include <set>
#include <sstream>
#include <string.h>
#include <map>
#include <iostream>


#define BUF_SIZE 3000

#define READ_BUF  do {is.getline(buf, BUF_SIZE); } while (is_comment(buf));


#define _COUT if (verbose) cout


bool is_comment(char *buf){
    if (buf[0] == (char)0)
	return true;  // emty line is a comment
    istringstream sis(buf); // create a stream from the string toi skip blanks
    string s;
    sis >> s;
    if (s.c_str()[0] == (char)0)
	return true;  // emty line with blanks is a comment
    return (s.c_str()[0] == '#');
}

// ----------------------------------------------------------------------
// Chemistry(fileName) (constructor, read from .rea file)  
// ----------------------------------------------------------------------

Chemistry::Chemistry(string fileName){
    verbose = 0;
    ifstream is(fileName.c_str());
    if (!is.good()){
	cerr << "ERROR (Chemistry): can't open " << fileName << endl;
	exit(0);
    }
    is >> theMolecules;     // read the molecules

    theReactions.setMolecules(&theMolecules); /* inform the reactions about 
						 the molecules names */

    theReactions.read(is, &theMolecules);     // read the reactions
}

Chemistry::Chemistry(){
    theReactions.setMolecules(&theMolecules); /* inform the reactions about 
						 the molecules names */
}


Chemistry::Chemistry(int m){ // create with m species
  
  theReactions.setMolecules(&theMolecules); /* inform the reactions about 
						 the molecules names */
  for (int i = 0; i < m;i++)
    theMolecules.insert(fun::itos(i));
}

// ----------------------------------------------------------------------
// Chemistry copy constructor
// ----------------------------------------------------------------------


// ----------------------------------------------------------------------
// Chemistry
// ----------------------------------------------------------------------
// (some functions are defined in Chemistry_fun.cpp)


//  Chemistry::reactions(A)
//  returns all reactions amoung molecules in A

TheReactions & Chemistry::reactions(set<Molecule> A){
    static TheReactions result;
    verbose = 0;
    TheReactions empty;
    result = empty;
    result.setMolecules(&theMolecules); /* the set of reaction should know
					  the names of the molecules. */
    
    unsigned int i;
    for( i=0;i < theReactions.size();i++) { // for each known reaction
	set<Molecule> left_side = (theReactions[i].first).mkset();
	if (fun::contains(A, left_side))
	    result.push_back(theReactions[i]);
    }
    return result;
}


void Chemistry::write(ostream & out) {
    out << "# Number of Components" << endl;
    out << theMolecules.size() << endl;
    out << "# Components" << endl;
    
    for(unsigned int i=0;i < theMolecules.size();i++){
	out << theMolecules[i].name << "\n";
    }


    out << "# Number of Reactions" << endl;
    out << theReactions.size() << endl;
    out << "# Reactions" << endl;
    theReactions.write(out);

}

string Chemistry::reactions_vcg(set<Molecule> A){
    string result;
    unsigned int i;

    TheReactions r = reactions(A);
    vector<string> reactionName;
    

    // create head

    result += "graph: { \n ";
    result += "title: \" Organization \" \n";
    result += "display_edge_labels: yes ";
    result += " xbase: 20 \n ybase: 20 \n height: 800 \n width: 1000 \n" ;


    // create all moleculs nodes

    set<Molecule>::iterator it;
    for(it=A.begin();it != A.end();it++){
	result += "node: {title:\"" + theMolecules.name(*it) + "\" "
	    + " shape:  box color: white} \n";
    }

    // create all reaction nodes

    for(i=0;i < r.size();i++){
	ostringstream reaction_name;

	reaction_name <<  "R" << i;
	reactionName.push_back(reaction_name.str());
	result += "node:  { title:\""; 
	result += reactionName[i];
	result += "\" shape:   rhomb color: white } \n";
    }

    // create all edges

    for(i=0;i < r.size();i++){  // for each reaction
	Molecules left_side = r[i].first;
	Molecules right_side = r[i].second;
    Molecules::iterator it;
	for(it = left_side.begin(); it != left_side.end();it++){
	    // for each mol. on left side create link to reaction node
	    result += "edge: { sourcename: \"";
	    result += theMolecules.name((*it).second) ;
	    result +="\"  targetname: \"";
	    result += reactionName[i];
	    result += "\"  arrowcolor: red color: red linestyle: continuous label: \"";
	    result +=  reactionName[i];
	    result += "\" } \n";
	}
	for(it = right_side.begin(); it != right_side.end();it++){
	    // for each mol. on left side create link to reaction node
	    result += "edge: { sourcename: \"";
	    result +=  reactionName[i] ;
	    result +="\"  targetname: \"";
	    result += theMolecules.name((*it).second);
	    result += "\"  arrowcolor: red color: red linestyle: continuous label: \"";
	    result +=  reactionName[i];
	    result += "\" } \n";
	}

    }

    // create tail


    result += "}\n";

	

    return result;
} 


// ------------------------------------------------------------

// gml format see:  http://infosun.fmi.uni-passau.de/Graphlet/GML/
 
/* EXAMPLE:

graph [
    comment "This is a sample graph"
    directed 1
    id 42
    label "Hello, I am a graph"
    node [
        id 1
        label "Node 1"
        thisIsASampleAttribute 42
    ]
    node [
        id 2
        label "node 2"
        thisIsASampleAttribute 43
    ]
    node [
        id 3
        label "node 3"
        thisIsASampleAttribute 44
    ]
    edge [
        source 1
        target 2
        label "Edge from node 1 to node 2"
    ]
    edge [
        source 2
        target 3
        label "Edge from node 2 to node 3"
    ]
    edge [
        source 3
        target 1
        label "Edge from node 3 to node 1"
    ]
]
*/


string Chemistry::reactions_gml(set<Molecule> A){
    bool reaction_nodes = false; // can be used as a parameter

    vector<string> node_names;
    string node_names_file_name = "node_names";
    int node_names_col = 2;

    // reading  node names

    if (node_names_file_name != "") {
	ifstream is (node_names_file_name.c_str());
	if (!is.good()){
	    cerr << "WARNING: can't open nodes_names_file: " 
		 << node_names_file_name << "\n";
	} else {
	    // read node names
	    for(uint i = 0; i < theMolecules.size();i++){
		for(int ii=1;ii < node_names_col ;ii++){
		    string DUMMY;
		    is >> DUMMY;
		}
		char buf[1000];
		is.getline(buf,1000);
		string name = buf;
		// replace " by blank
		for(uint j=0;j<name.size();j++)
		    if (name[j] == '"') 
			name[j] = ' ';
		
		node_names.push_back(name);
	    }
	    cerr << "node_names: " << node_names.size() << "\n";
	}
    }
 




    string result;
    unsigned int i;

    TheReactions r = reactions(A);
    vector<string> reactionName;
    

    // create head

    result += "graph [ \n ";
    result += "label \" THELABEL \" \n";
    result += "directed 1 \n";
 
    // create all moleculs nodes

    set<Molecule>::iterator it;
    for(it=A.begin();it != A.end();it++){
	char buf[100];
	sprintf(buf, "%d", *it);
	result += "node [ \n ";
	result += "    id " + string(buf) + " \n";
	result += "    labelAnchor \"c\"\n";
	result += "    label \"" 
	  + (*it < (int)node_names.size() ? node_names[*it] : theMolecules.name(*it))
	    + "\" \n";

	result += " graphics [ \n";
	result += "      x  200.0  \n";
	result += "      y  " + fun::itos(1+10*(*it)) + ".0 \n" ;
	result += "      type \"rectangle\"\n";
	result += "      w  25.0  \n";
	result += "      h  10.0  \n";
	result += "      fill \"#FFFFE4\"  \n";
	result += "      outline \"#000000\"  \n";
	
	result += "      width  1.2 \n";
	result += "]\n";

	result += "    LabelGraphics [ \n";
	result += "          type \"index_label\" \n";
	result += "          fill \"#000000\" \n";
	result += "          anchor \"c\"\n";
	result +="     ] \n";


	result += "]\n";
    }

    // create all reaction nodes

    if (reaction_nodes)
	for(i=0;i < r.size();i++){
	    ostringstream reaction_name;
	    int reaction_id = i + A.size();
	    reaction_name <<  "R" << i;
	    reactionName.push_back(reaction_name.str());
	    result += "node  [ \n ";
	    result += "      id " + fun::itos(reaction_id) + "\n";
	    result += "      label \"" + reactionName[i] + "\" \n";


	    // ------
	    result += " graphics [ \n";
	    result += "      x  100.0  \n";
	    result += "      y   " + fun::itos(1+10*i) + ".0 \n" ;
	    result += "      type \"oval\"\n";
	    result += "      w  10.0  \n";
	    result += "      h  10.0  \n";
	    result += "      fill \"#FFFFE4\"  \n";
	    result += "      outline \"#000000\"  \n";
	
	    result += "      width  0.4 \n";
	    result += "]\n";
	    // ------

	    // ------
	    result += "    LabelGraphics [ \n";
	    result += "          type \"index_label\" \n";
	    result += "          fill \"#000000\" \n";
	    result += "          anchor \"c\"\n";
	    result +="     ] \n";
	    // ------
	    
	    
	    result += "]\n";
	    
	}

    // create all edges

    for(i=0;i < r.size();i++){  // for each reaction
	Molecules left_side = r[i].first;
	Molecules right_side = r[i].second;
	Molecules::iterator it;
	if (reaction_nodes){
	    for(it = left_side.begin(); it != left_side.end();it++){
		// for each mol. on left side create link to reaction node
		result += "edge [ \n source ";
		result += fun::itos((*it).second) ;
		result +="\n  target ";
		result += fun::itos(i + theMolecules.size()) + "\n";  // reaction_id
		
		
		result += "graphics [  \n    type \"line\"\n   arrow \"last\" \n]\n";
		

/*
  result += "   label \"";
  result +=  reactionName[i];
  result += "\" \n";
*/
		result += "]\n";
	    }
	    for(it = right_side.begin(); it != right_side.end();it++){
		// for each mol. on left side create link to reaction node
		result += "edge [ \n source ";
		result +=  fun::itos(i + theMolecules.size());  // reaction_id
		result +="\n  target ";
		result += fun::itos((*it).second) + "\n";
/*
	    result += "   label \"";
	    result +=  reactionName[i];
	    result += "\" \n";
*/
		result += "]\n";
	    }
	} // if reaction_nodes
	//        -------------------
	else { // no reaction nodes
	    // --------------------
	    // connect directly to first product  (HACK !!!!)
	    Molecule first_right_side_molecule = right_side.begin()->second;
	    for(it = left_side.begin(); it != left_side.end();it++){
		// for each mol. on left side create link to the first
		// molecule on the right hand side (HACK !)

		result += "edge [ \n source ";
		result += fun::itos((*it).second) ;
		result +="\n  target ";
		result += fun::itos(first_right_side_molecule) + "\n";  // reaction_id
		
		
		result += "graphics [  \n    type \"line\"\n   arrow \"last\" \n]\n";
		

/*
  result += "   label \"";
  result +=  reactionName[i];
  result += "\" \n";
*/
		result += "]\n";
	    }

	}


    }

    // create tail


    result += "]\n";

	

    return result;
} 







// ----------------------------------------------------------------------
// TheMolecules
// ----------------------------------------------------------------------

Molecule TheMolecules::molecule(string name){
    unsigned int i;
    for(i=0;i < this->size();i++)
	if ((*this)[i].name == name)
	    return (Molecule)i;
    // return NO_MOLECULE;
    // cerr << "new molcule name: " << name << endl;
    return insert(name);
}

string TheMolecules::name(Molecule m){
    if (m == NO_MOLECULE)
	return ("NO_MOLECULE");
    if (checkbounds(m))
	return (*this)[m].name;
    return ("NO_MOLECULE");
}

Molecule TheMolecules::insert(string name){
    MoleculeInfo mi;
    mi.name = name;     
    mi.number = size(); // new number (current size of the vector)
    push_back(mi);
    return mi.number;
}

// ----------------------------------------------------------------------
// TheMolecules::set2names
// ----------------------------------------------------------------------
// auxilliar function
// maps a set of molecules to a set of their names
// ----------------------------------------------------------------------

set<string> TheMolecules::set2names(set<Molecule> ms){
    set<string> result;
    set<Molecule>::iterator it;
    for(it = ms.begin();it != ms.end();it++)
	result.insert(name(*it));
    return result;
}

set<string> TheMolecules::set2names_python(set<Molecule> ms){
    set<string> result;
    set<Molecule>::iterator it;
    for(it = ms.begin();it != ms.end();it++)
	result.insert("\"" + name(*it) + "\"");
    return result;
}
// **********************************************************************
//    Molecules
// **********************************************************************



set<Molecule> Molecules::mkset(){ // returns a set instead of the multi set
    set<Molecule> result;
 Molecules::iterator it;
    for(it = this->begin();it != this->end();it++)
	result.insert((*it).second);
    return result;
}

istream& operator>>(istream&is, TheMolecules  & tm){
    char buf[BUF_SIZE+1];

    // cerr << "reading molecules ..." << endl;

    READ_BUF;
    
    int number_of_molecules = atoi(buf);
    
    // cerr << number_of_molecules << "\t" << buf;

    for (int i=0;i < number_of_molecules;i++){
	  MoleculeInfo mi;	 

	  READ_BUF;
	  istringstream sis(buf); // create a stream from the string toi skip blanks
	  string molname;
	  sis >> molname;

	  mi.name = molname;
	  mi.number = i;
	  tm.push_back(mi);
	  // cerr << i << "\t" << buf << endl;
    }
    return is;
}

ostream& operator<<(ostream&os, TheMolecules  & tm){
    unsigned int i;
    os << tm.size() << endl;
    for(i = 0;i < tm.size();i++)
	os << tm.name(i) << endl;
    return os;
}

// ----------------------------------------------------------------------
//   TheReactions
// ----------------------------------------------------------------------


// new: 16.03.2017

bool TheReactions::reactionFromTo(Molecule a, Molecule b){
  // for each reaction
  for(unsigned int i=0;i < size();i++){
      // if a is a reactand and b is a product
    if ((*this)[i].isEduct(a) && (*this)[i].isProduct(b))
      return true;
    }
  return false;
}

bool TheReactions::reactionPathFromTo(Molecule a, Molecule b){
  if (!reactionPath[0][0]) // if path not computed yet   
    computeReactionPath(); // compute all reaction paths
  return reactionPath[a][b]; // return the requested path 
}




void TheReactions::computeReactionPath(){
  // init
  if (verbose)
    cout << "computeReactionPath: Computing reaction path ...\n";

  for (unsigned int i = 0; i < theMolecules->size(); i++)
    for (unsigned int j = 0; j < theMolecules->size(); j++)
      reactionPath[i][j] = reactionFromTo(i, j);
  
  
  // We asume that
  // for any a: there is a path from a to a   (no obvious! see graph theory)
  for (unsigned int i = 0; i < theMolecules->size(); i++)
    reactionPath[i][i] = true;
  
  // slow but should work
  for (unsigned int i = 0; i < theMolecules->size(); i++)
    for (unsigned int j = 0; j < theMolecules->size(); j++)
      for (unsigned int k = 0; k < theMolecules->size(); k++)
	for (unsigned int l = 0; l < theMolecules->size(); l++)
	  if (reactionPath[k][l] && reactionPath[l][j])
	    reactionPath[k][j] = true;
   if (verbose)
     cout << "   done \n" << endl;
}


void TheReactions::printAllPaths(ostream & os){
  for (unsigned int i = 0; i < theMolecules->size(); i++)
    for (unsigned int j = 0; j < theMolecules->size(); j++)
      if (reactionPathFromTo(i,j))
	os << theMolecules->name(i) << " -->  " << theMolecules->name(j) << endl;
}	  

void TheReactions::read(istream &is, TheMolecules *theMolecules){
    static char buf[BUF_SIZE];
    
    READ_BUF;
    int number_of_reactions = atoi(buf);

    _COUT << "reading " << number_of_reactions << " reactions ..." << endl;

    for (int i=0;i < number_of_reactions;i++){
	Reaction reaction;
	reaction.read(is, theMolecules);
	// reaction.read_without_order(is, theMolecules);
	push_back(reaction);
	// cerr << "reaction: " << i << "\t" << buf << endl;
    }
}


void TheReactions::write(ostream &os){
    unsigned int i;
    for(i=0;i < size();i++){
	(*this)[i].write(os, theMolecules); 
	os << "\n";
    }
}


void TheMolecules::write(ostream &os){
    unsigned int i;
    for(i=0;i < size();i++){
	(*this)[i].write(os); 
	os << "\n";
    }
}


ostream& operator<<(ostream& os, TheReactions  & tm){
    tm.write(os);
    return os;
}



// ----------------------------------------------------------------------
//    Reaction
// ----------------------------------------------------------------------

set<Molecule>  Reaction::productset(){
    // returns a set of the reaction products (righthandside) of that reaction
    return second.mkset();
}

set<Molecule> Reaction::eductset(){
    // returns a set of the reaction educts (lefthandside) of that reaction
    return first.mkset();
}


bool Reaction::isProduct(Molecule a){
  return productset().count(a);
}

bool Reaction::isEduct(Molecule a){
  return eductset().count(a);
}


void Reaction::read(istream & is, TheMolecules *theMolecules){
    char buf[BUF_SIZE];
    string dummy;

    READ_BUF;

    Molecules reactands;
    Molecules products;
    
    strcat(buf, "  "); // weiss der Teufel, warum dies notwendig ist

    istringstream sis(buf); // create a stream from the string

    if (buf[0] == 'R'){
	// is athmosphere network reaction
	string reaction_name;
	sis >> reaction_name;
	sis >> dummy; // skip "&"
	reactands.read_without_order_until(sis, "->", theMolecules);
	products.read_without_order_until(sis, "&", theMolecules);
    } else {
	// is metabolism network reaction
	reactands.read_until(sis, "->", theMolecules);
	products.read_until(sis, "&", theMolecules);
    }

    first = reactands;
    second = products;

    // read additional information

    char buf2[BUF_SIZE];
    sis.getline((char*)buf2, BUF_SIZE, '&');
    while (buf2[0]){
	string s(buf2);
	m_info.push_back(s);
	// cout << buf2 << "JJ";
	sis.getline((char*)buf2, BUF_SIZE, '&');
    }
    // cout << m_info.size() << endl;

    // set the reaction rate

    m_rate = 0;
    m_rate_defined = false;
    
    if (m_info.size() > 0) {
	double a = atof(m_info[0].c_str());
	if ((a == 0.0 && (m_info[0].find("0") != string::npos)) ||
	    a != 0.0 ){ 
	    // if a ==0, check whether the string contains really a "0"
	    m_rate = a;
	    m_rate_defined = true;
	}
    }


    init_m_productset_eductset();

/*
    // get the rest from the line -> buf
    sis.getline(buf, BUF_SIZE);
    cout << "buf: " << buf << endl;
*/
}


void Reaction::read_without_order(istream & is, TheMolecules *theMolecules){
    char buf[BUF_SIZE];
    string dummy;

    READ_BUF;

    Molecules reactands;
    Molecules products;
    strcat(buf, "  "); // weiss der Teufel, warum dies notwendig ist
    istringstream sis(buf); // create a stream from the string

    reactands.read_without_order_until(sis, "->", theMolecules);
    products.read_without_order_until(sis, "&", theMolecules);
    
    first = reactands;
    second = products;

    init_m_productset_eductset();

}



void Reaction::write(ostream & os, TheMolecules *theMolecules){
      
    Molecules reactands = first;
    Molecules products = second;

    reactands.write(os, theMolecules);
    os << " -> ";
    products.write(os, theMolecules);
}

// ----------------------------------------------------------------------
//   Molecules
// ----------------------------------------------------------------------

//
// example   1 A 2 B ->


// add n molecules to the multiset

void Molecules::insert(int n, Molecule m){
    // check whether molecule m is already in the multiset (slow !)
    // ein mieser Hack

    Molecules::iterator it;  
    Molecules::iterator found_it; 
    int n_old=0;
    bool found = false;
    for (it = this->begin() ; (it != this->end()) && !found; it++)  // for each entry 
	if (it->second == m) {
	    found_it = it;
	    n_old = found_it->first;
	    found = true;
	}
    pair<int, Molecule> new_pair(n+n_old, m);
    if (!found)
	set<pair<int, Molecule> >::insert(new_pair);
    else {
	// wirklich umstaendlich, aber man kann irgendwie nicht direkt das enthaltene
	// pair veraendern, seltsam
	erase(found_it);
	set<pair<int, Molecule> >::insert(new_pair);
    }
}
	

void Molecules::read_until(istream & is, string end_marker, TheMolecules *tm){
    string buf;
    is >> buf;
    while (!is.eof() && (buf != end_marker)){
	int order = atoi(buf.c_str()); 
	is >> buf; // read the name
	Molecule molecule_number = tm->molecule(buf);  // get molecules number
	// insert(pair<int, Molecule>(order, molecule_number)); 
	insert(order, molecule_number);
	// cerr << "read_until: order: " << order 
	//     << " molecule_name: " << buf 
	//     << "  molecule_number: " << molecule_number << endl;

	is >> buf;
    }
}
	       

void Molecules::write(ostream & os,  TheMolecules *tm){
    Molecules::iterator it;
    for(it = begin();it != end(); it++){
	os << (*it).first
	   << " "
	   << tm->name((*it).second)
	   << " ";
    }
}
	
 
//
// example    A  B ->

void Molecules::read_without_order_until(istream & is, string end_marker, TheMolecules *tm){
    string buf;
    is >> buf;
    while (!is.eof() && (buf != end_marker)){
	int order = 1;
	Molecule molecule_number = tm->molecule(buf);
	insert(order, molecule_number);
	is >> buf;
    }
}
	 
	   

// ----------------------------------------------------------------------
//   remove_self_replicators
// ----------------------------------------------------------------------
// workarround, not clean yet !!!

void TheReactions::remove_self_replicators(){
    _COUT << "removing self-replicators ...";
    int old_size = this->size();

    TheReactions result;
    result.setMolecules(theMolecules);
    unsigned int i;
    for(i=0;i < this->size(); i++){
	if ((*this)[i].first != (*this)[i].second)
	    result.push_back((*this)[i]);
    }
    result.verbose = this->verbose;
    (*this) = result;   // !!!
    
    _COUT << "  " << old_size - this->size() 
	 << " self-replicator equations removed." << endl;
}

void TheReactions::remove_reversible_reactions(){
    _COUT << "removing reversible reactions ...";
    int old_size = this->size();

    TheReactions result;
    result.setMolecules(theMolecules);
    unsigned int i,ii;
    for(i=0;i < this->size(); i++){
	bool is_reversible = false;
	for(ii=0;(ii < this->size()) && !is_reversible ; ii++)
	    if (((*this)[i].first == (*this)[ii].second) &&
		((*this)[i].second == (*this)[ii].first))
		is_reversible = true;
	if (!is_reversible)    
	    result.push_back((*this)[i]);
    }
    result.verbose = this->verbose;
    (*this) = result;   // !!!
    _COUT << "  " << old_size - this->size() 
	 << " reversible reaction equations removed." << endl;
}





// A StochMatrix is simply a m x 2*n matrix
// sm[0..m-1][0..2n-1]
//  m: number of reactions
//  n: number of molecules

StochMatrix::StochMatrix(int m, int n){  // n: number of molecules
    vector<int> emptyRow(2*n);
    int i=0;
    for(i=0;i < m;i++)
	this->push_back(emptyRow);
}


// ----------------------------------------------------------------------
//     TheReactions -> Dynamics     
// ----------------------------------------------------------------------

StochMatrix  TheReactions::make_stoch_matrix(){
    int m= size();
    int n=theMolecules->size();
    StochMatrix sm(m, n);   /* sm[reactionNo][molNo] = reactand order of molNo
			       sm[reactionNo][molNo+n] = product order of molNo
			    */
    int i;
    for (i=0;i < m;i++){ // for each reaction
	Molecules & lhs = (*this)[i].first;
	Molecules & rhs = (*this)[i].second;
	Molecules::iterator it;  
	for (it = lhs.begin() ; it != lhs.end(); it++) { // for each entry on the left hand side of r
	    int order = (*it).first;
	    Molecule mol = (*it).second;
	    sm[i][mol] += order;
	}
	for (it = rhs.begin() ; it != rhs.end(); it++) { // for each entry on the right hand side of r
	    int order = (*it).first;
	    Molecule mol = (*it).second;
	    sm[i][n+mol] += order;
	}
    }
    return sm;
}

map<string, double> TheReactions::default_parameter(){
    map<string, double> par;
    par["catalytic"] = 1.0;
    par["simplex"] = 1.0;
    return par;
}




void TheReactions::make_ode_octave(ostream & os, map<string, double> par){
    bool catalytic = par["catalytic"];
    // bool simplex = par["simplex"];

    StochMatrix sm = make_stoch_matrix();
    

    int n = theMolecules->size();  // n: number of molecules
    int m = this->size();          // m: number of reactions
    _COUT << sm << endl;


    // _____ head ______

    os << "# function created by TheReactions::make_ode_octave \n"
       << "# number_of_molecules " << n << "\n"
       << "# number_of_reactions " << m << "\n\n";

    os << "function xdot = f(x, t) \n";

    // ____ the equations ____


    int i,j,k;

    // first the rates of each reaction j
    
    for (j=0; j < m;j++) {  // for each reaction
	int asterix = 0;
	os << "r(" << j+1 << ") = ";
	if ((*this)[j].rate_defined())
	    if ((*this)[j].rate() != 1)
		os << (*this)[j].rate() << "*";
	for(i=0;i < n;i++)  { // for each molecule 
	    int order = sm[j][i]; 
	    if (order > 0) {
		if (asterix++) 
		    os << "*";
		os << "x(" << i+1 << ")";
		if (order > 1) 
		    os << "**" << order;
	    }
	}
	os << "\n";
    }

    // the derivative of each concentration i

    for(i=0;i < n;i++)  { // for each molecule 
	os << "xdot(" << i+1 << ") = 0" ;  // NOTE: octave starts to count with 1!
	for (j=0; j < m;j++) {  // for each reaction
	    k = sm[j][n+i] - (catalytic? 0 : sm[j][i] );
	    if (k > 0)
		os <<  "+ " << k << " * r(" << j+1 << ")";
	    if (k < 0)
		os << k << " * r(" << j+1 << ")";
	}
	// dilution flux
	os << "- x(" << i+1 << ") * Phi ";

	os << endl;
    }
    // ____ the body _____

    os << "\n" << "endfunction\n";
    
}


