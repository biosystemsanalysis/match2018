#ifndef OP_XX2
#define OP_XX2

#include <set>
#include <vector>
#include <string>
#include <iostream>

#include "Chemistry.h"

// (the following could be done more elegantly by using templates
//  but so far let's try to avoide them)

// operators for sets

ostream& operator<<(ostream&s, set<int> isSet);
istream& operator>>(istream&s, set<int> & isSet);
ostream& operator<<(ostream&s, set<string> stringSet);

ostream& operator<<(ostream&s, set<set<int> > isSet);
ostream& operator<<(ostream & t, set<vector<double> > dsSet);

// operators for vectors

ostream& operator<<(ostream&s, vector<double> v);
ostream& operator<<(ostream&s, vector<bool> v);
ostream& operator<<(ostream&s, vector<int> v);

ostream& operator<<(ostream&s, vector<vector<int> > v);
ostream& operator<<(ostream&s, vector<set<int> > v);

// set union
set<Molecule> operator+(const set<Molecule> A, const set<Molecule> B);
// set intersection
set<Molecule> operator*(const set<Molecule> A, const set<Molecule> B);
// set minus
set<Molecule> operator-(const set<Molecule> A, const set<Molecule> B);

// set of sets union
set<set<Molecule> >operator+(const set<set<Molecule> > A, const set<set<Molecule> > B);

// set of sets minus
set<set<Molecule> >operator-(const set<set<Molecule> > A, const set<set<Molecule> > B);


#endif 
