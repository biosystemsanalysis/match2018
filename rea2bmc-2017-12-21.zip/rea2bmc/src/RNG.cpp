// RNG.cpp: implementation of the rng class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "artchem.h"
#include "RNG.h"
#include "stdlib.h"

#include <time.h>
#include <iostream>

   #include <unistd.h>

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif


// #define _USE_RAND
// #define _USE_DRAND48
#define _USE_RAN2







//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

rng::rng()
{
    
}

rng::~rng(){
}


// ------------------------------------------------------------
//   RNG
// ------------------------------------------------------------
//  Rewrite the following three interface functions in order
//  to change the RNG.

#ifdef _USE_RAND

int rng::randomSeed (int seed){
    int the_seed=seed;
    
    if (seed==0)
	the_seed=time(0)+13*getpid();
    srand(the_seed);
    // cerr << "seed: " << the_seed << " " << "pid: " << getpid() << endl;
    return the_seed;
}
int rng::randomInt (int min, int max){
    return min + (rand() % (max+1 - min));
}

double rng::randomReal (double min, double max){
    return min + (((double)rand()/RAND_MAX)* (max - min));
}

double rng::randomReal (){
    return ((double)rand()/RAND_MAX);
}

#endif


#ifdef _USE_DRAND48


// drand 48
#include <stdlib.h>

int rng::randomSeed (int seed){
    int the_seed=seed;
    
    if (seed==0)
	the_seed=time(0)+13*getpid();
    srand48(the_seed);
    // cerr << "seed: " << the_seed << " " << "pid: " << getpid() << endl;
    return the_seed;
}
int rng::randomInt (int min, int max){
    return min + (lrand48() % (max+1 - min));
}

double rng::randomReal (double min, double max){
    return min + (((double)drand48())* (max - min));
}

double rng::randomReal (){
    return ((double)drand48());
}





#endif


// **********************************************************************
//              RAN2
// **********************************************************************


#define IM1 2147483563
#define IM2 2147483399
#define AM (1.0/IM1)
#define IMM1 (IM1-1)
#define IA1 40014
#define IA2 40692
#define IQ1 53668
#define IQ2 52774
#define IR1 12211
#define IR2 3791
#define NTAB 32
#define NDIV (1+IMM1/NTAB)
#define EPS 1.2e-7
#define RNMX (1.0-EPS)



#ifdef _USE_RAN2

int rng::randomSeed (int seed){
    int the_seed=seed;
    
    if (seed==0)
	the_seed=time(0)+13*getpid();

    rng::ran2Seed((long)the_seed);
    return the_seed;
}

int rng::randomInt (int min, int max){
  unsigned diff = max - min;
  return rng::ran2() % (diff+1) + min;
}

double rng::randomReal (double min, double max){
  return min + (((double)rng::ran2Float())* (max - min));
}

double rng::randomReal (){
  return ((double)rng::ran2Float());
}


#endif 
 


// from: numerical recipies in C : ran2()


long rng::idum[1];		// definition internal stuff for rand2
long rng::idum2;
long rng::iy;
long rng::iv[32]; 


// *************
//   ran2 seed
// *************

void	rng::ran2Seed(long pSeed){
  rng::idum[0] = pSeed;
}


// *************
//   ran2 
// *************

long rng::ran2(){
  int j;
  long k;

  // float temp;

  if (rng::idum[0] <= 0) {
    if (-(rng::idum[0]) < 1) rng::idum[0]=1;
    else rng::idum[0] = -(rng::idum[0]);
    rng::idum2=(rng::idum[0]);
    for (j=NTAB+7;j>=0;j--) {
      k=(rng::idum[0])/IQ1;
      rng::idum[0]=IA1*(rng::idum[0]-k*IQ1)-k*IR1;
      if (rng::idum[0] < 0) rng::idum[0] += IM1;
      if (j < NTAB) rng::iv[j] = rng::idum[0];
    }
    rng::iy=rng::iv[0];
  }
  k=(rng::idum[0])/IQ1;
  rng::idum[0]=IA1*(rng::idum[0]-k*IQ1)-k*IR1;
  if (rng::idum[0] < 0) rng::idum[0] += IM1;
  k=rng::idum2/IQ2;
  rng::idum2=IA2*(rng::idum2-k*IQ2)-k*IR2;
  if (rng::idum2 < 0) rng::idum2 += IM2;
  j=rng::iy/NDIV;
  rng::iy=rng::iv[j]-rng::idum2;
  rng::iv[j] = rng::idum[0];
  if (rng::iy < 1) rng::iy += IMM1;
	
  return rng::iy;		//new

  //	if ((temp=AM*rng::iy) > RNMX) return RNMX;	// fuer float
  //	else return temp;
}

float rng::ran2Float(){
  float temp;
  if ((temp = rng::ran2() * rng::iy) > RNMX) return RNMX;	
  else return temp;
}


 
#undef IM1
#undef IM2
#undef AM
#undef IMM1
#undef IA1
#undef IA2
#undef IQ1
#undef IQ2
#undef IR1
#undef IR2
#undef NTAB
#undef NDIV
#undef EPS
#undef RNMX
/* (C) Copr. 1986-92 Numerical Recipes Software 5.)$1. */

