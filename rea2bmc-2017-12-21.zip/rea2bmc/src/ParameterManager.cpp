/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   ParameterManager.cpp
 * Author: peter
 * 
 * Created on 6. Oktober 2016, 17:26
 */

#include "ParameterManager.h"


#include <stdlib.h> 
#include <string>
#include <iostream>

ParameterManager::ParameterManager(int argc, char *argv[]) {
    argc_ = argc;
    argv_ = argv;
    // parse the command line parameters
    for (int i = 1; i < argc; i++){
        std::string arg = argv[i];
        if (arg.at(0)=='-'){
            // paramter found
            std::string parName = arg.substr(1, arg.size()); // remove - sign
            // get next argv element
            i++;
            if (i == argc){
                std::cerr << "ERROR in command line arguments. Missing value for: " << arg << std::endl;
                exit(0);
            }
            parameters[parName] = argv[i];
        } else {
            fileNames_.push_back(arg); // is file name
        }
        
    }
}

ParameterManager::ParameterManager(const ParameterManager& orig) {
}

ParameterManager::~ParameterManager() {
}

int ParameterManager::get_int(std::string parName, int defaultVal) {
    if (parameters.count(parName))
        return std::stoi(parameters.at(parName));
    return defaultVal;
}

std::string ParameterManager::get_string(std::string parName, std::string defaultVal) {
    if (parameters.count(parName))
        return parameters.at(parName);
    return defaultVal;
}


