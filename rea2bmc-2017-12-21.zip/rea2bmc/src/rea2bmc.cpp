// 
// 
//  Peter Dittrich                 B i o   S y s t e m s   A n a l y s i s
//  Jena, 2003 - 2017             Dept. of Mathematics and Computer Science
//                                 Friedrich-Schiller-University Jena, Germany
//     _______________________   http://www.informatik.uni-jena.de/~dittrich/
//
// Using a slightly modified version of the Lattice code by Pietro Speroni di Fenizio
// to store the lattice of closed sets.

#define VERSION "1.6"


/*
 * ------------------------------------------------------------------------------------------
 * This tool finds all binary molecular codes [1] (BMC, formaly known as IBOC) in a given 
 * reaction network. The network has to be provided in "rea" format.
 * Various output options are available.
 *
 * 
 * 
 * [1] D. Görlich / P. Dittrich (2013), Molecular Codes in Biological and 
 *     Chemical Reaction Networks, 8(1): e54694,  
 *     http://dx.doi.org/10.1371/journal.pone.0054694
 *
 *
 * Warning: This code has grown over years, written in different moods and styles,
 *          including no style at all. So, beware the inconsistencies in naming, structure,
 *          organization, and workarounds through lazyiness. 
 *
 * Comments and corrections are welcome.
 * ------------------------------------------------------------------------------------------
 */

/*

Version 28.04.2017:
  - fun::contains(A,B) improved
    Before it was elegantly implemented as (A intersection B) == B. 
    Now we check for each element from B whether it is contained in A.
    Seems to be faster.




Version 05.04.2017
  - Working on: skip the closure computation if  MAX_number_of_closures reached.


 */


/*
 * Version 21.03.2017:
 *  - We compute union_of_closure only for those required.
 *    This improves drastically the speed. (factor of 10 to 20)
 *  
 */


// Version 20.03.2017
//   - Checking whether there is a path from sign to meaning
//     Improves drastically the speed of the main-loop. 
//     However, preparing the index sets (contains and closure union)
//     now takes the majority of time.


// Version 16.03.2017
//  - more efficient by checking one pair of context only once
//    (only 20% faster, not clear why)
//  - small improvemnt in checking the signes



// Version 05.09.2016
//   - old parameter manager PM removed
//   - all warnings eliminated
//   - verbose output improved  (  -verbose 0  results in no output at all)
//   - python friendly output added


// #define MAX_number_of_closures 30000
// ( TODO: make this dynamic )

#define MAX_number_of_closures 10000



#include <set>
#include <chrono>
#include <limits>
#include <iostream>
#include <iomanip>

#include "Chemistry.h"
#include "OrgTheory.h"
#include "fun.h"

#include "RNG.h"
#include "operators.h"
#include "Lattice/Lattice.h"

#include "ParameterManager.h"

#define _COUT if (verbose) cout
#define _PY if (python) cout
#define _BMC if (bmc_out) *bmc_out
#define SN(x) chemistry.theMolecules.set2names(x)
#define SNpy(x) chemistry.theMolecules.set2names_python(x)

// some crazy defines for time measurement in seconds
#define NOW  std::chrono::system_clock::now()
#define STARTCLOCK auto clock_start = NOW
#define ELAPSED std::chrono::duration_cast<std::chrono::seconds>(NOW - clock_start).count()
    

int doc = 0;

set<Molecule> read_set(string fileName) {
    ifstream is(fileName.c_str());
    if (!is.good()) {
        cerr << "ERROR (read_set): can't open " << fileName << endl;
        exit(0);
    }
    set<Molecule> result;
    is >> result;
    return result;
}

// Create array to memoize "contains" and "closure of unions" operators

bool contains[MAX_number_of_closures][MAX_number_of_closures];
int closure_of_union[MAX_number_of_closures][MAX_number_of_closures];




// _____ MAIN ________________________________________________________________________________________


int main(int argc, char *argv[]) {
    // rng::randomSeed((int)time((time_t *)0)); 

    // for runtime measurement
    STARTCLOCK;
    
    // init parameter manager
    ParameterManager pm(argc, argv); // parse command line parameters

    if (argc < 2) {
        cout << "USE: rea2bmc [parameters] [sourceFilenames] \n"
                << "     version: " << VERSION << "\n"
                << "EXAMPLE:  \n"
                << "         rea2bmc example.rea \n"
                << "          This creates also a file example.ltc with the lattice of closed sets\n"
                << "          and a file example.bmc with molecular codes in python friendly format.\n"
                << "          Note that instead of a single molecules as signs and meanings their closre\n"
                << "          is given (single molecule closure). That is, if two different molecules \n"
                << "          can function as signs but generate the same closed set, they are listed only once.\n"
                << "\n"
                << "\n"
                << "          \n"
                << "         rea2bmc -verbose 0 -saveltc 0 -savebmc 0 -python 1 example.rea\n"
                << "           This will create a python friendly output to stdout\n"
                << "           without any other side effects (no files are written).\n"
                << "\n"
                << "\n"
                << "PARAMETERS: \n"

                << "          -rmselfrep 1 (remove self-replicators)\n"
                << "          -rmrevrea 1  (remove reversible reactions)\n"
                << "          -verbose 0   (silent mode, no output to stdout)\n"
                << "          -verbose 2   (detailed log output)\n"
                << "          -verbose 4   (print number of function calls)\n"
                << "          -verbose 255 (full log output)\n"
                << "          -input [FILENAME]   (a file containing input molecules as numbers, do not use)\n"
                << "          -saveltc 0   (do not save ltc file)\n"
                << "          -savebmc 0  (do not save bmc file, curently example.ibic is in python format)\n"
                << "          -python 1    (a python friendly output to stdout, should be combined with -verbose 0)"
                << "          \n"
                << "          \n"
                << endl;
        exit(0);
    }


    // ___ set the command line parameters ____________________

    int rmselfrep = pm.get_int("rmselfrep", 0);
    int rmrevrea = pm.get_int("rmrevrea", 0);
    int verbose = pm.get_int("verbose", 1);
    int saveltc = pm.get_int("saveltc", 1);
    int savebmc = pm.get_int("savebmc", 1);
    int python = pm.get_int("python", 0);
    string inputFileName = pm.get_string("inputFileName", "");
    doc = pm.get_int("doc", 0);

    string input_file = inputFileName; // not really usefull, some old stuff

    for (auto & fileName : pm.fileNames()) {
        // new c++11 range technique for iterating
        // seems that this confuses Netbeans  (9/2016)

        // set base_name to fileName and remove .rea if present
        string base_name = fileName;
        if (fileName.size() > 4)
            if (fileName.substr(fileName.size() - 4, 4) == ".rea")
                base_name = fileName.substr(0, fileName.size() - 4);

        string rea_filename = base_name + ".rea";

        _COUT << "reading:  " << rea_filename << endl;


        // now we use base_name to construct other output file names
        string ltc_filename = base_name + ".ltc";
        string bmc_filename = base_name + ".bmc";
        string doc_filename = base_name + ".ltc.doc";


        ofstream *os_doc = 0, *bmc_out = 0;
        if (doc)
            os_doc = new ofstream(doc_filename.c_str());

        if (savebmc) {
            bmc_out = new ofstream(bmc_filename.c_str());
            if (!bmc_out->is_open()) {
                cerr << "ERROR: can't open output file: " << bmc_filename << endl;
                exit(0);
            }
            _COUT << "creating: " << bmc_filename << endl;

        }


        if (saveltc)
            _COUT << "creating: " << ltc_filename << endl;


        Chemistry chemistry(rea_filename); // make the Chemistry object by reading the rea-file
        chemistry.theReactions.verbose = verbose;


        if (verbose & 2) {
            chemistry.theMolecules.write(cout);
            chemistry.theReactions.write(cout);
        }

        if (rmselfrep)
            chemistry.remove_self_replicators();
        if (rmrevrea)
            chemistry.remove_reversible_reactions();

        OrgTheory orgTheory(chemistry); // make an OrgTheory object for closure calculations

        orgTheory.verbose = verbose;



        _COUT << "\n\n";
        /*
          if (chemistry.theReactions.size()< 30)
          chemistry.theReactions.write(cout);
          if (chemistry.theMolecules.size() < 30)
          chemistry.theMolecules.write(cout);
         */

        _COUT << "\n----------------------------------------\n";
        _COUT << "Number of molecules: " << chemistry.theMolecules.size() << endl;
        _COUT << "Number of reactions: " << chemistry.theReactions.size() << endl;
        _COUT << "\n----------------------------------------\n";

	
	// ------------------------------------------------------------
	// print all pairs a --> b such that there is a path from a to b
	// cout << "\nAll Paths:\n";
	// chemistry.theReactions.printAllPaths(cout);
	// ------------------------------------------------------------
	
        set<Molecule> all, largest_closure, input;

        // Create the set of all molecules: all

        for (unsigned int i = 0; i < chemistry.theMolecules.size(); i++)
            all.insert(i);

        // Read input file if requested: input

        if (input_file != "") {
            input = read_set(input_file.c_str());
            _COUT << "input_size: " << input.size() << endl;
        } else {
            _COUT << "input_size: " << "no_input \n";
        }

        // Generate largest closure
        // (trivial, should not be different from "all" !

        largest_closure = orgTheory.closure(all, input);
        _COUT << "size_of_largest_closure: " << largest_closure.size() << endl;


        set<set<int> >::iterator it;

        // ------------------------------------------------------------
        //    make the lattice
        // ------------------------------------------------------------

        set<set<int> > all_closures = orgTheory.all_closures(largest_closure, input, MAX_number_of_closures);

        _COUT << "\n\nnumber_of_closures: " << all_closures.size() << endl;

        Lattice lattice2;

        for (it = all_closures.begin();
                it != all_closures.end();
                it++) {
            lattice2.Insert(*it);
            if (doc)
                *os_doc << (*it)
                << endl
                    << chemistry.theMolecules.set2names(*it) << endl;
            // _COUT << "inserting " << *it << endl;  // information can be found in ltc file generated
        }

        // if doc write the lattice nodes information in doc
        lattice2.NameNodes();
        if (doc) {

            *os_doc << "\n\n";
            Nodes::iterator it = lattice2.Nodes::begin();
            while (it != lattice2.Nodes::end()) {
                set<Molecule> mset;
                ints::iterator itN = (*it)->begin();
                // unused: int i1=(*it)->size();
                *os_doc << " Org.Num= " << (*it)->m_iNumber;
                *os_doc << " #Elem= " << (*it)->size() << " { ";
                while (itN != (*it)->end()) {
                    *os_doc << " " << *itN;
                    mset.insert(*itN);
                    itN++;
                }
                *os_doc << "\n" << chemistry.theMolecules.set2names(mset) << "\n" << endl;
                it++;
            }
        }

        // and save the lattice

        if (saveltc > 0)
            lattice2.fprint(ltc_filename.c_str());


        // ----------------------------------------------------------------------
        // Let's find the bmcs
        // hmmm, the following naiv algorithm is quite slow (and not complete)
        // ----------------------------------------------------------------------
        /*
        for(its1 = all_closures.begin(); its1 != all_closures.end(); its1++){
          cout << ". " << *its1 << endl;
          its2 = its1; for(its2++ ; its2 != all_closures.end(); its2++){
            cout << ".";
            cout.flush();
            itm1 = its2; for(itm1++ ; itm1 != all_closures.end(); itm1++){
              itm2 = itm1; for(itm2++ ; itm2 != all_closures.end(); itm2++){
                itc1 = itm2; for(itc1++ ; itc1 != all_closures.end(); itc1++){
                  itc2 = itm1; for(itc2++ ; itc2 != all_closures.end(); itc2++){
                    // check for BMC
                    if ( fun::contains(orgTheory.closure(*its1 + *itc1), *itm1) &&    // m1 IN Closure(S1 u C1)
                         fun::contains(orgTheory.closure(*its2 + *itc1), *itm2) &&    // m2 IN Closure(S2 u C1)
                         fun::contains(orgTheory.closure(*its1 + *itc2), *itm2) &&    // m2 IN Closure(S1 u C2)
                         fun::contains(orgTheory.closure(*its2 + *itc2), *itm1) &&     // m1 IN Closure(S2 u C2)
                         !fun::contains(orgTheory.closure(*its1 + *itc1), *itm2) &&    // m1 IN Closure(S1 u C1)
                         !fun::contains(orgTheory.closure(*its2 + *itc1), *itm1) &&    // m2 IN Closure(S2 u C1)
                         !fun::contains(orgTheory.closure(*its1 + *itc2), *itm1) &&    // m2 IN Closure(S1 u C2)
                         !fun::contains(orgTheory.closure(*its2 + *itc2), *itm2)){      // m1 IN Closure(S2 u C2)
                      cout << "\nBMC:  " << *its1 << "  " << *its2 
                           << "  " << *itm1 << "  " << *itm2 
                           << "  " << *itc1  << "  " << *itc2 
                           << endl;
                      break;
                    }
                  }
                }
              }
            }
          }
        }
         */
        // ----------------------------------------------------------------------


        // ------------------------------------------------------------------
        //    Hashing / Memoizing closures, union and contains operations
        // ------------------------------------------------------------------
        
        int number_of_closures = all_closures.size();

        // Create a vector of all closures and a mapping getting back the index of a closure
                
        vector < set<int> > closure;            //   closure index -->  closure (a set)
        map< set<int>, int> closure_index;      // closure (a set) --> closure index

        {
            int i = 0;
            for (it = all_closures.begin(); it != all_closures.end(); it++) {
                closure.push_back(*it);
                closure_index[*it] = i;
                i++;
            }
        }

        // ok, this is bad style, better using a dynamically allocated data struct.
        // PD (5.4.2017): changed "<" to "<=" 
        if (MAX_number_of_closures <= number_of_closures) {
            cerr << "Unsufficient space: too many closures " << number_of_closures << endl;
            cerr << " Maximal number of allowed closures: " << MAX_number_of_closures << endl
                    << " Solution: Either reduce the input network or recompile this program" << endl
                    << "           with larger MAX_number_of_closures ." << endl;


            exit(0);
        }
        
        
        // ____ Calculating all unions of closures and contains relationship ______  (can be very time consuming)

        _COUT << "\nCalculating all unions of closures and contains relationship:" << endl;

	for (int i = 0; i < number_of_closures; i++) {
            _COUT << ".";
	    if ((i % 40) == 0)
	      _COUT << "(" << std::setprecision(3) << (double) i * 100 / (double) number_of_closures << "\%)";
            _COUT.flush();
            for (int ii = 0; ii < number_of_closures; ii++) {
                contains[i][ii] = fun::contains(closure[i], closure[ii]);
                
                // The following calculation of the closure_of_union has been moved below
                // because we only require the union of a single molecular closure i
                // with a closure ii. (PD 21.03.2017)
                //
                // set<int> U = closure[i] + closure[ii];
                // closure_of_union[i][ii] = closure_index[orgTheory.closure(U)];
                             
            }
        }   


        // ___ Create a vector of all closures that can be generated from a single species
        // only these we will consider as signals and meanings.

        set < set<Molecule> > single_molecule_closures;

	map< int, set<Molecule> > single_molecule_generators_of_closure_index;
	// maps a single molecule closure index to a set of molecules generating that closure
	
        for (unsigned int i = 0; i < chemistry.theMolecules.size(); i++) { // for each molecule
	  set<Molecule> single_molecule_set, closure; // create a set with a single molecule
            single_molecule_set.insert(i);
	    closure = orgTheory.closure(single_molecule_set);
            single_molecule_closures.insert(closure); // insert its closure in the set

	    // Remember the single molecule generators of each closure,
	    // index of the closure: closure_index[*it];
	    single_molecule_generators_of_closure_index[closure_index[closure]].insert(i);  // molecule i
	}

        unsigned int number_of_single_molecule_closures = single_molecule_closures.size();

        // Make an array with indexes of these closures

        _COUT << "\nsingle_molecule_closures:\n--------------------------\n";

        int single_molecule_closures_index[number_of_single_molecule_closures]; // single mol. closure index --> closure index
        {
            int i = 0;
            for (set < set<Molecule> >::iterator it = single_molecule_closures.begin(); it != single_molecule_closures.end(); it++) {
                single_molecule_closures_index[i] = closure_index[*it];
                _COUT << i << "\t" << *it << "\t" << single_molecule_closures_index[i] << endl;
                i++;
            } 
        }
	
        // ____ Compute closure_of_union(si, ii)   si: only for single molecule closures required
        // 
        
	for (unsigned int si = 0; si <  number_of_single_molecule_closures; si++) {
            int i = single_molecule_closures_index[si];
            _COUT << ".";
	    if ((si % 40) == 0)
	      _COUT << "(" << std::setprecision(3) << (double) si * 100 / (double) number_of_closures << "\%)";
            _COUT.flush();
            for (int ii = 0; ii < number_of_closures; ii++) {
                
                set<int> U = closure[i] + closure[ii];
                closure_of_union[i][ii] = closure_index[orgTheory.closure(U)];
            }
        }   

        
        

        int molecule_2_closure_index[chemistry.theMolecules.size()]; 
        for (unsigned int i = 0; i < chemistry.theMolecules.size(); i++) { // for each molecule
	  set<Molecule> single_molecule_set; // create a set with a single molecule
	  single_molecule_set.insert(i);
	  molecule_2_closure_index[i] = closure_index[orgTheory.closure(single_molecule_set)];
	}
	
	// ___   Compute: isPath ______________________________________________________________________

	// Create array to memoize whether there is a path from one closed set A to another closed set B.
	// There is a path from closed set A to B, if there is a molecule a from A such that there 
	// is a path to a molecule b from B  AND the closure of { b }  is equal to B, i.e., B is a single molecular
	// closure of b.

	//  We check in following:  A (with index i) --> B  (with index j)

	_COUT << "Computing isPath ..." << endl;

	bool isPath[number_of_single_molecule_closures][number_of_single_molecule_closures];

	for(unsigned int i = 0; i < number_of_single_molecule_closures;i++)
	  for(unsigned int j = 0; j < number_of_single_molecule_closures;j++)
	    if (i == j){
	      isPath[i][j] = true;  // we assume that there is always a path from a set to itself
	    } else {
	      isPath[i][j] = false;
	      // for each molecule y that is a generator of j
	      for (unsigned int y = 0; y < chemistry.theMolecules.size(); y++){
		if (molecule_2_closure_index[y] == single_molecule_closures_index[j]){
		  //   for each molecule x in i
		  set<Molecule> closure_i = closure[single_molecule_closures_index[i]];
		  for (set<Molecule>::iterator it_x = closure_i.begin(); it_x != closure_i.end();it_x++){ 
		      //      if there is a path x --> y
		      if (chemistry.theReactions.reactionPathFromTo(*it_x, y))
			  //          isPath[i][j] = true
			  isPath[i][j] = true;  // (kept like that for better readability)

		  }
		}
	      }
	    }
	
    	_COUT << "    done (isPath)" << endl;
	      
	      
	   
	      

	

	

	// _____________________________________________________________________________________________
	
	// --------------------------------------------------------------------------------
        //  MAIN LOOP: check all combinations of closed sets with respect
        //   to the property of a binary molecular code.
	// --------------------------------------------------------------------------------

        unsigned int bmc_anz = 0;

        unsigned int its1, its2, itm1, itm2;

        unsigned long n = number_of_single_molecule_closures;
        unsigned long m = number_of_closures;
        long combinationsToCheck = n * n * n * n * m*m; // this is evil
	
        _COUT << "combinationsToCheck: " << combinationsToCheck << endl;
        _PY << "[ \n";
        _BMC << "[ \n";

	for (unsigned int s1 = 0; s1 < number_of_single_molecule_closures-1; s1++) {
	  _COUT << "(" << std::setprecision(3) << (double) s1 * 100 / (double) number_of_single_molecule_closures << "\%)";
	  // _COUT << closure[s1] << " " << closure_index[closure[s1]] << endl;
            for (unsigned int s2 = s1+1; s2 < number_of_single_molecule_closures; s2++) {
                _COUT << ".";
                cout.flush();
                for (unsigned int m1 = 0; m1 < number_of_single_molecule_closures-1; m1++) {
                    for (unsigned int m2 = m1+1; m2 < number_of_single_molecule_closures; m2++) {
                        if (isPath[s1][m1] && isPath[s1][m2] && isPath[s2][m1] && isPath[s2][m2]){
                        its1 = single_molecule_closures_index[s1]; // get the closure index of the single mol closures
                        its2 = single_molecule_closures_index[s2];
                        itm1 = single_molecule_closures_index[m1];
                        itm2 = single_molecule_closures_index[m2];
                        for (unsigned int itc1 = 0; (int)itc1 < number_of_closures-1; itc1++) {
			  for (unsigned int itc2 = itc1+1; (int)itc2 < number_of_closures; itc2++) {
                                // check for BMC
                                if (contains[closure_of_union[its1][itc1]][itm1] && // m1 IN Closure(S1 u C1)
                                        contains[closure_of_union[its2][itc1]][itm2] && // m2 IN Closure(S2 u C1)
                                        contains[closure_of_union[its1][itc2]][itm2] && // m2 IN Closure(S1 u C2)
                                        contains[closure_of_union[its2][itc2]][itm1] && // m1 IN Closure(S2 u C2)
                                        !(contains[closure_of_union[its1][itc1]][itm2]) && // m1 IN Closure(S1 u C1)
                                        !(contains[closure_of_union[its2][itc1]][itm1]) && // m2 IN Closure(S2 u C1)
                                        !(contains[closure_of_union[its1][itc2]][itm1]) && // m2 IN Closure(S1 u C2)
                                        !(contains[closure_of_union[its2][itc2]][itm2])) { // m1 IN Closure(S2 u C2)
				    _COUT << "\n\nNew_BMC_found_number: " << bmc_anz << endl;
                                    _COUT << " BMC:  " << bmc_anz << "   " << closure[its1] << "  " << closure[its2]
                                            << "  " << closure[itm1] << "  " << closure[itm2]
                                            << "  " << closure[itc1] << "  " << closure[itc2]
                                            << endl;
                                    _COUT << " BMCn:  " << bmc_anz << "   " << SN(closure[its1]) << "  " << SN(closure[its2])
                                            << "  " << SN(closure[itm1]) << "  " << SN(closure[itm2])
                                            << "  " << SN(closure[itc1]) << "  " << SN(closure[itc2])
                                            << endl;

                                    // explain the bmc
                                    _COUT << "\nEXPLAIN:  S1 = " << SN(closure[its1])
                                            << "  S2 = " << SN(closure[its2])
                                            << "\n M1 =  " << SN(closure[itm1])
                                            << "   M2 = " << SN(closure[itm2])
                                            << "\n C = " << SN(closure[itc1])
                                            << "    C' = " << SN(closure[itc2])
                                            << "\n S1 + C  --> " << SN(closure[closure_of_union[its1][itc1]])
                                            << "\n S2 + C  --> " << SN(closure[closure_of_union[its2][itc1]])
                                            << "\n S1 + C' --> " << SN(closure[closure_of_union[its1][itc2]])
                                            << "\n S2 + C' --> " << SN(closure[closure_of_union[its2][itc2]])
					  << endl << endl ;
                                    // python friendly output
                                    if (bmc_anz > 0) {
                                        _PY << " , " << endl;
                                        _BMC << " , " << endl;
                                    }
                                    _PY << " [ " << SNpy(closure[its1]) << " , "
                                            << SNpy(closure[its2]) << " , "
                                            << SNpy(closure[itm1]) << ", "

                                            << SNpy(closure[itm2]) << ","
                                            << SNpy(closure[itc1]) << ","
                                            << SNpy(closure[itc2]) << " ]";
                                    _BMC << " [ " << SNpy(closure[its1]) << " , "
                                            << SNpy(closure[its2]) << " , "
                                            << SNpy(closure[itm1]) << ", "

                                            << SNpy(closure[itm2]) << ","
                                            << SNpy(closure[itc1]) << ","
                                            << SNpy(closure[itc2]) << " ]";
                                    bmc_anz++;
                                    goto XX;   // ignore further different contexts that implment the same code
                                }
                            }
                        }
                    }   
XX:
                        ;     
                    }
                }
            }
        }
        _PY << "\n]" << endl;
        _BMC << "\n]" << endl;
        _COUT << "\n\nBMCANZ: " << bmc_anz << endl;
        _COUT << "    Note that this number counts an bmc and its dual only once.\n"
                << "    Thus there are at least twice as many bmcs.\n"
                << "    Further note that if two molecules generate the same closed set, \n"
                << "    They are considered as one molecule, as we only look at he closed set they generate.\n"
                << "    So, there can be much more bmcs, but they are just trivial variants of each other." << endl;
    }

    _COUT << "elapsedTime: " << ELAPSED << endl;
    
    if (verbose & 4) {
        cout << "\nFUNCTION_CALLS:\n";
        fun::count_calls_print(cout);
        cout << "\nNUMBER_OF_DIFFERENT_INPUT_SETS:\n";
        fun::count_sets_print(cout);
    }

}
