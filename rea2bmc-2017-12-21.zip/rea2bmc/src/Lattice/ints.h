// ints.h: interface for the ints class.
//
//////////////////////////////////////////////////////////////////////

/*

5.8.02 Constructor for set<int> added (Peter).
       This allows a cast from set<int> to ints.



 */


#if !defined(AFX_INTS_H__371F4F09_E2DD_4DAD_8954_D76421C1C701__INCLUDED_)
#define AFX_INTS_H__371F4F09_E2DD_4DAD_8954_D76421C1C701__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

// #pragma warning(disable:4786)
#include <set>

using namespace std ;

class intms;

class ints : public set<int>  
{

public:
	void full(int n);
	ints();
	ints(const ints & oNewOrg);
	ints(const set<int> & oNewOrg);
  
	intms tointms();

	virtual ~ints();
	bool contains(const ints & isElements) const;
	bool contains(const set<int> & isElements) const;
	bool contains(const intms & isElements) const;

	ints operator+=(const ints& rhs);
	ints operator*=(const ints& rhs);
	ints operator-=(const ints& rhs);

};
ints operator+(const ints& lhs, const ints& rhs);
ints operator-(const ints& lhs, const ints& rhs);
ints operator*(const ints& lhs, const ints& rhs);//the Intersection

ostream& operator<<(ostream&s,ints isSet);

#endif // !defined(AFX_INTS_H__371F4F09_E2DD_4DAD_8954_D76421C1C701__INCLUDED_)




