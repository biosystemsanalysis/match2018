// intms.h: interface for the intms class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_INTMS_H__C7E95309_1EFE_483A_A9C3_89E00B26051F__INCLUDED_)
#define AFX_INTMS_H__C7E95309_1EFE_483A_A9C3_89E00B26051F__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// #pragma warning(disable:4786)
#include <set>
#include <string>
#include "ints.h"

using namespace std ;

class intms  : public multiset<int>  
{
public:
	intms();
	virtual ~intms();
	ints toints();
	bool read_until(istream & is,string str);
	

};

#endif // !defined(AFX_INTMS_H__C7E95309_1EFE_483A_A9C3_89E00B26051F__INCLUDED_)
