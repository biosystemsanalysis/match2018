// Nodes.h: interface for the Nodes class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_NODES_H__953369FD_B9D9_462E_B920_7451A2D3CBD0__INCLUDED_)
#define AFX_NODES_H__953369FD_B9D9_462E_B920_7451A2D3CBD0__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#include "Node.h"

class Nodes : public set<Node *>  
{
public:
	void Assert();
	Nodes();
	virtual ~Nodes();
	void RemoveCoveredNodes();
	void RemoveCoveringNodes();
	bool AreIndependent();
};

#endif // !defined(AFX_NODES_H__953369FD_B9D9_462E_B920_7451A2D3CBD0__INCLUDED_)
