// NodeIn.cpp: implementation of the NodeIn class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "artchem.h"
#include "NodeIn.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

NodeIn::NodeIn()
{

}

NodeIn::~NodeIn()
{

}

//const Nodes NodeIn::Above(){return nsAbove;}
//const Nodes NodeIn::Below(){return nsBelow;}
const NodeLinks NodeIn::Above(){return lksAbove;}
const NodeLinks NodeIn::Below(){return lksBelow;}

NodeIn::NodeIn(const ints & oNewOrg):Node(oNewOrg)
{

}

bool NodeIn::insertAbove(Node * pndNewNode, InfoLink * pil)
{return	lksAbove.insert( NodeLinks::value_type(pndNewNode,pil) ).second;}

bool NodeIn::insertBelow(Node * pndNewNode, InfoLink * pil)
{return	lksBelow.insert( NodeLinks::value_type(pndNewNode,pil) ).second;}

NodeLinks::size_type  NodeIn::eraseAbove(Node * pndNewNode)
{return lksAbove.erase(pndNewNode);}

NodeLinks::size_type  NodeIn::eraseBelow(Node * pndNewNode)
{return lksBelow.erase(pndNewNode);}

ostream& operator<<(ostream&s,NodeIn &niNode)
{
	ints::iterator it=niNode.begin();
	s<<"Org.Num="<<niNode.m_iNumber<<" #Elem="<<niNode.size()+"{";
	if(it!=niNode.end())	
	{	s	<<*it;  
		it++;
	}
	while(it!=niNode.end())	
		{	s <<"   "<<*it;
			it++;
		}
	s<<"}\n";
	return s;
}

InfoLink * NodeIn::findBelow(Node * pndTestNode)
{
	NodeLinks::iterator it=lksBelow.find(pndTestNode);
	if(it==lksBelow.end()) return NULL;
	return (*it).second;
}

InfoLink * NodeIn::findAbove(Node * pndTestNode)
{
	NodeLinks::iterator it=lksAbove.find(pndTestNode);
	if(it==lksAbove.end()) return NULL;
	return (*it).second;
}

void NodeIn::Assert()
{
	Node * pndTemp;
	InfoLink * pilTemp;

	NodeLinks::iterator it=lksAbove.begin();
	while(it!=lksAbove.end()) 
	{
		pndTemp=(*it).first;
		pilTemp=(*it).second;
		assert(pndTemp);
		assert(pilTemp);
		assert(pndTemp->findBelow(this)==pilTemp);

		it++;
	}

	it=lksBelow.begin();
	while(it!=lksBelow.end()) 
	{
		pndTemp=(*it).first;
		pilTemp=(*it).second;
		assert(pndTemp);
		assert(pilTemp);
		assert(pndTemp->findAbove(this)==pilTemp);
		it++;
	}
}