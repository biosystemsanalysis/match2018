// Nodes.cpp: implementation of the Nodes class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "artchem.h"
#include "Nodes.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

Nodes::Nodes()
{

}

Nodes::~Nodes()
{
}

bool Nodes::AreIndependent()
{
	iterator it1=begin();
	iterator it2;
	it1++;
	while(it1!=end())
	{
		it2=begin();
		while(it2!=it1)
		{
			if(	(*it1)->contains(**it2)	) 
				return false;
			if(	(*it2)->contains(**it1)	) 
				return false;
			it2++;
		 }
		 it1++;
	 }
	 return true;
}

void Nodes::RemoveCoveredNodes()
{
	iterator it1=begin();
	if(it1==end())return;
	it1++;
	iterator it2;
	iterator itTemp;
	while(it1!=end())
	{
		it2=begin();
		while(it2!=it1)
		{		
			if(	(*it2)->contains(**it1)	) 
			{	itTemp=it1;
				itTemp++;
				erase(it1);
				if(itTemp==end()) 
					return;
				it2=begin();
				it1=itTemp;
				continue;	
			}
			if(	(*it1)->contains(**it2)	) 
			{	itTemp=it2;
				itTemp++;
				erase(it2);
				it2=itTemp;
				continue;	
			}
			it2++;
		}
		it1++;
	 }
}

void Nodes::RemoveCoveringNodes()
{
	iterator it1=begin();
	if(it1==end())return;
	it1++;
	iterator it2;

	iterator itTemp;

	while(it1!=end())
	{
		it2=begin();
		while(it2!=it1)
		{
			if(	(*it1)->contains(*(*it2))	) 
			{	itTemp=it1;
				itTemp++;
				erase(it1);
				if(itTemp==end()) 
					return;
				it2=begin();
				it1=itTemp;
				continue;	
			}
			if(	(*it2)->contains(*(*it1))	) 
			{	itTemp=it2;
				itTemp++;
				erase(it2);
				it2=itTemp;	
				continue;	
			}
			it2++;
		 }
		it1++;
	}
}

void Nodes::Assert()
{
	iterator it=begin();
	while(it!=end())
	{
		(*it)->Assert();
		it++;
	 }
}
