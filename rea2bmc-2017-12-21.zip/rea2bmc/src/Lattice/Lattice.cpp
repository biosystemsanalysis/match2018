// Lattice.cpp: implementation of the Lattice class.
//
//////////////////////////////////////////////////////////////////////

#include <iostream>

#include "stdafx.h"
#include "artchem.h"
#include "Lattice.h"
#include "stdlib.h"




#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

Lattice::Lattice()
{
Nodes::insert(&n0Root);
Assert();
}

Lattice::~Lattice()
{
	Nodes::iterator it=Nodes::begin();
	while(it!=Nodes::end())
	{
		if(!(*it)->IsNode0())		
		{
			const NodeIn * niNode=(NodeIn*)(*it);
			delete (niNode);
		}
		Nodes::erase(it);
		it=Nodes::begin();
	}

	Links::iterator lit=Links::begin();
	while(lit!=Links::end())
	{
		delete (*lit).second;
		Links::erase(lit);
		lit=Links::begin();
	}
}


bool Lattice::Insert(ints  oNewOrg)
{
	Nodes nsAbove;
	Nodes nsBelow;
//	Nodes nsIndependent;
	Nodes::iterator it=Nodes::begin();
	while(it!=Nodes::end())
	{
		if((*it)->contains(oNewOrg))
		{
			if((*it)->size()==oNewOrg.size())
			{
				it++;
				continue;	
			}	
			nsAbove.insert(*it);
			it++;
			continue;
		}	
		if(oNewOrg.contains(**it))
		{
			nsBelow.insert(*it);
			it++;
			continue;
		}	
//		nsIndependent.insert(*it);
		it++;
	}	

	nsAbove.RemoveCoveringNodes();
	nsBelow.RemoveCoveredNodes();
	Insert(oNewOrg,nsAbove,nsBelow);
	return true;
}


void Lattice::Insert(ints oNewOrg, Nodes & nsAbove, Nodes & nsBelow)
{
	Nodes::iterator itBelow;
	Nodes::iterator itAbove;
	NodeIn * niNewNode= new NodeIn(oNewOrg);
	InfoLink * plkNewLink;

	Nodes::insert(niNewNode);
	Links::iterator lit;

	bool blTemp;

	itAbove=nsAbove.begin();
	while(itAbove!=nsAbove.end())
	{
		plkNewLink= new	InfoLink();
		blTemp=Links::insert(Links::value_type(Link	(niNewNode,*itAbove),	plkNewLink)).second;	assert(blTemp);
		blTemp=(*itAbove)->insertBelow(niNewNode,plkNewLink);								assert(blTemp);
		blTemp=niNewNode->insertAbove(*itAbove,plkNewLink);									assert(blTemp);
		itAbove++;
	}

	itBelow=nsBelow.begin();
	while(itBelow!=nsBelow.end())
	{
		plkNewLink= new	InfoLink();
		blTemp=Links::insert(Links::value_type(Link	(*itBelow,niNewNode),	plkNewLink)).second;	assert(blTemp);
		blTemp= niNewNode->insertBelow(*itBelow,	plkNewLink);	assert(blTemp);
		blTemp=(*itBelow)->insertAbove(niNewNode,	plkNewLink);	assert(blTemp);
		itBelow++;
	}	
	
	itBelow=nsBelow.begin();
	while(itBelow!=nsBelow.end())
	{
		itAbove=nsAbove.begin();
		while(itAbove!=nsAbove.end())
		{
			lit=Links::find(Link(*itBelow,*itAbove));
			if(lit!=Links::end())
			{	plkNewLink=(*lit).second;
				delete plkNewLink;
				Links::erase(lit);
				assert((*itBelow)->findAbove(*itAbove));
				assert((*itAbove)->findBelow(*itBelow));
				(*itBelow)->eraseAbove(*itAbove);
				(*itAbove)->eraseBelow(*itBelow);
			}
			itAbove++;
		}
		itBelow++;
	}
}







void Lattice::NameNodes()
{
	Nodes::iterator it=Nodes::begin();
	int iCounter=0;
	while(it!=Nodes::end())
	{	
		(*it)->m_iNumber=iCounter;
		iCounter++;
		it++;
	}
}


ostream& operator<<(ostream& s, Lattice & ltLattice)
{

    ltLattice.NameNodes(); // PD: added 30.06

	Nodes::iterator it=ltLattice.Nodes::begin();
	s<<"#N= "<<ltLattice.Nodes::size()<<"\n";
	NodeIn nd;
	while(it!=ltLattice.Nodes::end())
	{	
		
		ints::iterator itN=(*it)->begin();
		// int i1=(*it)->size();
		s<<" Org.Num= "<<(*it)->m_iNumber;
		s<<" #Elem= "<<(*it)->size()<<" { ";
		if(itN!=(*it)->end())	
		{	s	<<*itN;  
			itN++;
		}
		while(itN!=(*it)->end())	
		{	s <<"   "<<*itN;
				itN++;
		}
		s << " }\n" ;		
		it++;
	}

	s<<"#L= "<<ltLattice.Links::size()<<"\n";
	Links::iterator lit=ltLattice.Links::begin();
	while(lit!=ltLattice.Links::end())
	{
		s <<"( ";
		s <<((*lit).first).first->m_iNumber;
		s <<" Below ";
		s <<((*lit).first).second->m_iNumber;
		s<<" ) Upload= "		<<(*lit).second->m_dUp;
		s<<" , Download= "	<<(*lit).second->m_dDown;
		s<<"\n";
		lit++;
	}
	s<<(char)0;
	return s;
}

/*
 * Peter: 6/10/16: write no longer needed, since we have the stream output method above
 * 
string Lattice::write()
{
	string str;
	Nodes::iterator it=Nodes::begin();
	{	char buf[100];
		sprintf(buf,"#N= %d\n",Nodes::size());
		str=str+buf;
	}
	NodeIn nd;
	while(it!=Nodes::end())
	{	
		ints::iterator itN=(*it)->begin();
		int i1=(*it)->size();
		{	char buf[100];
			sprintf(buf," Org.Num= %d #Elem=  { ",(*it)->m_iNumber,(*it)->size());
			str=str+buf;
		}

		if(itN!=(*it)->end())	
		{	char buf[100];
			sprintf(buf,"%d,",*itN);
			str=str+buf;
			itN++;
		}
		while(itN!=(*it)->end())	
		{	char buf[100];
			sprintf(buf,"    %d",*itN);
			str=str+buf;
			itN++;
		}
		{	char buf[100];
			sprintf(buf," }\n");
			str=str+buf;
		}
		it++;
	}

	{	char buf[100];
		sprintf(buf,"#L= %d\n",Links::size());
		str=str+buf;
	}

	Links::iterator lit=Links::begin();
	while(lit!=Links::end())
	{
		char buf[100];
		sprintf(buf,"( %d Below %d ) Upload= %g, Download= %g\n",
							((*lit).first).first->m_iNumber,
							((*lit).first).second->m_iNumber,
							(*lit).second->m_dUp,
							(*lit).second->m_dDown);	
		str=str+buf;
		lit++;
	}
	return str;
}
 */

void Lattice::fprint(string fileName){
    ofstream os(fileName.c_str());

    if (!os.good()){
	cerr << "Can't write file " << fileName << endl;
	exit(0);
    }

    os << *this;    
}

void Lattice::EmptyLattice()
{
	Nodes::iterator it=Nodes::begin();
	while(it!=Nodes::end())
	{
		if(!(*it)->IsNode0())		
		{
			const NodeIn * niNode=(NodeIn*)(*it);
			delete (niNode);
		}
		Nodes::erase(it);
		it=Nodes::begin();
	}

	Links::iterator lit=Links::begin();
	while(lit!=Links::end())
	{
		delete (*lit).second;
		Links::erase(lit);
		lit=Links::begin();
	}
	Nodes::insert(&n0Root);
}


void Lattice::Assert()
{
#ifdef _DEBUG

	Nodes::Assert();

	Nodes::iterator itStudied=Nodes::begin();
	Nodes::iterator itA;
	Nodes::iterator itB;
	while(itStudied!=Nodes::end())
	{
		Nodes nsAbove;
		Nodes nsBelow;
		Nodes nsIndependent;
		Nodes::iterator it=Nodes::begin();
		while(it!=Nodes::end())
		{
			if(it==itStudied) {	it++;continue;}	
			if((*it)->contains(**itStudied))
			{
				nsAbove.insert(*it);
				it++;
				continue;
			}	
			if((*itStudied)->contains(**it))
			{
				nsBelow.insert(*it);
				it++;
				continue;
			}	
			nsIndependent.insert(*it);
			it++;
		}

		itA=nsAbove.begin();
		while(itA!=nsAbove.end())
		{
			itB=nsBelow.begin();
			while(itB!=nsBelow.end())
			{	
				ASSERT((*itA)->findBelow(*itA)==NULL);
				itB++;
			}
			itA++;
		}
		itStudied++;
	}
#endif
}
