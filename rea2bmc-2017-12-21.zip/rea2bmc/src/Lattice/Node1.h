// Node1.h: interface for the Node1 class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_NODE1_H__04F1FCA5_B9DC_483E_98E1_0F53B8ACCD1B__INCLUDED_)
#define AFX_NODE1_H__04F1FCA5_B9DC_483E_98E1_0F53B8ACCD1B__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#include "Node.h"
#include "Nodes.h"

class Node1  : public Node  
{
public:
	Node1();
	virtual ~Node1();

private:
	Nodes ndsBelow;
};

#endif // !defined(AFX_NODE1_H__04F1FCA5_B9DC_483E_98E1_0F53B8ACCD1B__INCLUDED_)


