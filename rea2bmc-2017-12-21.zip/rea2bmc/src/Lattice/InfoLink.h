// InfoLink.h: interface for the InfoLink class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_INFOLINK_H__0F8B6B6D_4FA7_4A62_A4A5_AB8CC6061E6A__INCLUDED_)
#define AFX_INFOLINK_H__0F8B6B6D_4FA7_4A62_A4A5_AB8CC6061E6A__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

class InfoLink  
{
public:
	InfoLink();
	virtual ~InfoLink();
	double m_dDown;
	double m_dUp;
};

bool operator<(const InfoLink& lhs,const InfoLink& rhs);

#endif // !defined(AFX_INFOLINK_H__0F8B6B6D_4FA7_4A62_A4A5_AB8CC6061E6A__INCLUDED_)
