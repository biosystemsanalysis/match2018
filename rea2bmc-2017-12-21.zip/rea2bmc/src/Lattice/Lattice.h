// Lattice.h: interface for the Lattice class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_LATTICE_H__5B19BC2B_25F0_489E_BE18_F34A223CE97D__INCLUDED_)
#define AFX_LATTICE_H__5B19BC2B_25F0_489E_BE18_F34A223CE97D__INCLUDED_

#include "Node0.h"	// Added by ClassView
#include "NodeIn.h"	// Added by ClassView
#include <string>
#include <fstream>
#include "Nodes.h"	// Added by ClassView
#include "Links.h"	// Added by ClassView

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

class Lattice : public Nodes,  public Links
{
public:
	void Assert();
	string write();
	void EmptyLattice();
	void NameNodes();
	bool Insert(ints orgNewOrg);
	Node0 n0Root;
	Lattice();
	virtual ~Lattice();
	void fprint(string fileName);
private:
	void Insert(ints oNewOrg, Nodes &nsAbove, Nodes &nsBelow);
};

ostream& operator<<(ostream&s,Lattice & ltLattice);
#endif // !defined(AFX_LATTICE_H__5B19BC2B_25F0_489E_BE18_F34A223CE97D__INCLUDED_)
