// intms.cpp: implementation of the intms class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "artchem.h"
#include "intms.h"
#include "ints.h"
#include "stdlib.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

intms::intms()
{

}

intms::~intms()
{

}

ints intms::toints()
{
	ints isTemp;
	intms::iterator it=begin();
	while(it!=end())
	{
	isTemp.insert(*it);
	it++;
	}
	return isTemp;
}

bool intms::read_until(istream & is,string str)
{
	string buf;
	is >> buf;
	while((!is.eof()) && (buf != str))
	{
		int order = atoi(buf.c_str());
		is >> buf;
		if(buf == str) return false;
		int mol = atoi(buf.c_str());
		if(buf == str) return false;
		int i;
		for(i=0;i < order;i++)
			insert(mol);
		is >> buf;
	}
	return true;
}
