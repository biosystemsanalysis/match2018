// NodeIn.h: interface for the NodeIn class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_NODEIN_H__F531F9BF_AAE2_4D23_9919_1C224B15681C__INCLUDED_)
#define AFX_NODEIN_H__F531F9BF_AAE2_4D23_9919_1C224B15681C__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#include "Node.h"
#include "Nodes.h"


class NodeIn : public Node  
{
public:
	virtual void Assert();
	InfoLink * findBelow(Node * pndTestNode);
	InfoLink * findAbove(Node * pndTestNode);

	bool insertAbove(Node * pndNewNode,InfoLink * pil);
	bool insertBelow(Node * pndNewNode,InfoLink * pil);
	NodeLinks::size_type eraseAbove(Node * pndNewNode);
	NodeLinks::size_type eraseBelow(Node * pndNewNode);

	virtual bool IsNode0(){return false;};

	NodeIn(const ints & oNewOrg);
	const NodeLinks Above();
	const NodeLinks Below();
	NodeIn();
	virtual ~NodeIn();

private:
	NodeLinks lksAbove;
	NodeLinks lksBelow;
};

ostream& operator<<(ostream&s,NodeIn & niNode);


#endif // !defined(AFX_NODEIN_H__F531F9BF_AAE2_4D23_9919_1C224B15681C__INCLUDED_)
