// InfoLink.cpp: implementation of the InfoLink class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "artchem.h"
#include "InfoLink.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

InfoLink::InfoLink()
{
	m_dDown=0;
	m_dUp=0;
}

InfoLink::~InfoLink()
{

}

bool operator<(const InfoLink& lhs,const InfoLink& rhs)
{
if (lhs.m_dDown<rhs.m_dDown) return true;
if (lhs.m_dDown>rhs.m_dDown) return false;
if (lhs.m_dDown<rhs.m_dDown) return true;
return false;
}
