// Node0.h: interface for the Node0 class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_NODE0_H__3584ABF0_EF86_4348_9E6F_DCCFFD35A69F__INCLUDED_)
#define AFX_NODE0_H__3584ABF0_EF86_4348_9E6F_DCCFFD35A69F__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#include "Node.h"
#include "Nodes.h"


class Node0  : public Node  
{
public:
	virtual void Assert();
	bool insertAbove(Node * pndNewNode, InfoLink * pil);
	NodeLinks::size_type  eraseAbove(Node * pndNewNode);

	bool insertBelow(Node * pndNewNode, InfoLink * pil);
	NodeLinks::size_type eraseBelow(Node * pndNewNode);

	virtual bool IsNode0(){return true;};
	virtual	InfoLink * findBelow(Node *){return NULL;};

	InfoLink * findAbove(Node * pndTestNode);
	
	Node0();
	virtual ~Node0();

	const NodeLinks Above();
	const NodeLinks Below();


private:
	NodeLinks lksAbove;
	NodeLinks lksBelow;
};

	ostream& operator<<(ostream&s,Node0 niNode);


#endif // !defined(AFX_NODE0_H__3584ABF0_EF86_4348_9E6F_DCCFFD35A69F__INCLUDED_)
