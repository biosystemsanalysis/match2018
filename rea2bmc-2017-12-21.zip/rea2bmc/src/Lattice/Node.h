// Node.h: interface for the Node class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_NODE_H__13CADBAC_C9C2_441B_8412_39A6F888FDFD__INCLUDED_)
#define AFX_NODE_H__13CADBAC_C9C2_441B_8412_39A6F888FDFD__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

// #pragma warning(disable:4786)
#include <set>
#include <iostream>

using namespace std;

#include <assert.h>

//#include "Organisation.h"
#include "ints.h"	// Added by ClassView
#include "Links.h"

//class Nodes;
typedef map<Node *,InfoLink *> NodeLinks;

class Node  : public ints
{
public:
	virtual void Assert()=0;
	virtual bool IsNode0()=0;
	virtual const NodeLinks Below()=0;
	virtual const NodeLinks Above()=0;
	virtual InfoLink * findBelow(Node *)=0;
	virtual InfoLink * findAbove(Node *)=0;

	int m_iNumber;
	Node();
	virtual ~Node();

	virtual bool insertAbove(Node * pndNewNode,InfoLink * pil)=0;
	virtual	bool insertBelow(Node * pndNewNode,InfoLink * pil)=0;
	virtual	NodeLinks::size_type eraseAbove(Node * pndNewNode)=0;
	virtual	NodeLinks::size_type eraseBelow(Node * pndNewNode)=0;

	Node(const ints & oNewOrg);
};
ostream& operator<<(ostream&s,const Node & Node);
#endif // !defined(AFX_NODE_H__13CADBAC_C9C2_441B_8412_39A6F888FDFD__INCLUDED_)

