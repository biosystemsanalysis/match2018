// Node.cpp: implementation of the Node class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "artchem.h"
#include "Node.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

Node::Node()
{

}

Node::~Node()
{

}

Node::Node(const ints & oNewOrg):ints(oNewOrg)
{

}
ostream& operator<<(ostream&s,const Node & Node)
{
	ints::iterator it=Node.begin();
	s<<"Org.Num="<<Node.m_iNumber<<" #Elem="<<Node.size()<<"{";
	if(it!=Node.end())	
	{	s	<<*it;  
		it++;
	}
	while(it!=Node.end())	
	{	s <<" , "<<*it;
			it++;
	}
	s << "}\n" ;

	return s;
}

