// Node0.cpp: implementation of the Node0 class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "artchem.h"
#include "Node0.h"


#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

Node0::Node0()
{

}

Node0::~Node0()
{

}

const NodeLinks Node0::Above(){return lksAbove;}
const NodeLinks Node0::Below(){
	NodeLinks lksBelow;
	return lksBelow;}


bool Node0::insertAbove(Node * pndNewNode, InfoLink * pil)
{	return	lksAbove.insert( NodeLinks::value_type(pndNewNode,pil) ).second;}

Links::size_type  Node0::eraseAbove(Node * pndNewNode)
{	return	lksAbove.erase( pndNewNode);}


bool Node0::insertBelow(Node * pndNewNode, InfoLink * pil)
{return false;}

Links::size_type Node0::eraseBelow(Node * pndNewNode)
{return (Links::size_type)0;}

ostream& operator<<(ostream&s, Node0 n0Node)
{s <<"Org.Num="<<n0Node.m_iNumber<<" #Elem=0 {}";
return s;}

InfoLink * Node0::findAbove(Node * pndTestNode)
{
	NodeLinks::iterator it=lksAbove.find(pndTestNode);
	if(it==lksAbove.end()) return NULL;
	return (*it).second;
}

void Node0::Assert()
{
	Node * pndTemp=NULL;
	InfoLink * pilTemp=NULL;
	InfoLink * pilTemp2=NULL;

	NodeLinks::iterator it=lksAbove.begin();
	while(it!=lksAbove.end()) 
	{
		pndTemp=(*it).first;
		pilTemp=(*it).second;
		assert(pndTemp);
		assert(pilTemp);
		pilTemp2=pndTemp->findBelow(this);
		assert(pilTemp2);
		assert(pilTemp2==pilTemp);
		it++;
	}
}
