// Link.h: interface for the Link class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_LINK_H__F5B72D55_1139_490A_A2E3_075BE9486A58__INCLUDED_)
#define AFX_LINK_H__F5B72D55_1139_490A_A2E3_075BE9486A58__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// #pragma warning(disable:4786)
#include <map>

using namespace std ;

#include "InfoLink.h"

class Node;

class Link  : public map<pair<Node *,Node *>,InfoLink>
{
public:
	Link();
	virtual ~Link();

};

//((lower link, higher link), info)

#endif // !defined(AFX_LINK_H__F5B72D55_1139_490A_A2E3_075BE9486A58__INCLUDED_)
