// Links.h: interface for the Links class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_LINKS_H__D6D30BA9_91F1_4AC4_94EE_0B69D1CA9620__INCLUDED_)
#define AFX_LINKS_H__D6D30BA9_91F1_4AC4_94EE_0B69D1CA9620__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

// #pragma warning(disable:4786)
#include <map>

using namespace std ;



#include "InfoLink.h"
class Node;
typedef  pair<Node *,Node *> Link;

class Links : public map<Link,InfoLink *>
{
public:
	Links();
	virtual ~Links();

};

#endif // !defined(AFX_LINKS_H__D6D30BA9_91F1_4AC4_94EE_0B69D1CA9620__INCLUDED_)
