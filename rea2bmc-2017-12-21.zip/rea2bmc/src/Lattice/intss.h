// intss.h: interface for the intss class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_INTSS_H__6ECAA09F_6EAE_4107_A049_B283BF6BD4C6__INCLUDED_)
#define AFX_INTSS_H__6ECAA09F_6EAE_4107_A049_B283BF6BD4C6__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#include "ints.h"

class intss : public set<ints>  
{
public:
	//void ExtractTopMost();
	intss();
	virtual ~intss();

};

#endif // !defined(AFX_INTSS_H__6ECAA09F_6EAE_4107_A049_B283BF6BD4C6__INCLUDED_)
