// ints.cpp: implementation of the ints class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "artchem.h"
#include "ints.h"
#include <iostream>
#include "intms.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

ints::ints()
{

}

ints::~ints()
{

}
ints::ints(const ints & oNewOrg):set<int>(oNewOrg)
{

}

ints::ints(const set<int> & oNewOrg):set<int>(oNewOrg)
{

}


intms ints::tointms()
{
	intms INTMS;
	ints::iterator it=begin();
	while(it!=end())
	{
	INTMS.insert(*it);
	it++;
	}
	return INTMS;
}


bool ints::contains(const ints & isElements) const
{
	ints:: iterator it1=begin();
	ints:: iterator it2=isElements.begin();
	bool blTest;
	while(it2!=isElements.end())
	{
		blTest=false;
		it1=begin();
		while(it1!=end())
		{
			if(	(*it1)==(*it2)) //it could be much faster with a <= or >=
				{blTest=true;
				break;}
      		it1++;
		}
		if(!blTest) return false;
		it2++;
	}
	return true;
}

bool ints::contains(const intms & isElements) const
{
	ints:: iterator it1=begin();
	intms:: iterator it2=isElements.begin();
	bool blTest;
	while(it2!=isElements.end())
	{
		blTest=false;
		it1=begin();
		while(it1!=end())
		{
			if(	(*it1)==(*it2)) //it could be much faster with a <= or >=
			{
				blTest=true;
				break;
			}
      		it1++;
		}
		if(!blTest) 
			return false;
		it2=isElements.upper_bound(*it2);
	}
	return true;
}

bool ints::contains(const set<int> & isElements) const
{
	ints:: iterator it1=begin();
	ints:: iterator it2=isElements.begin();
	bool blTest;
	while(it2!=isElements.end())
	{
		blTest=false;
		it1=begin();
		while(it1!=end())
		{
			if(	(*it1)==(*it2)) //it could be much faster with a <= or >=
				{blTest=true;
				break;}
      		it1++;
		}
		if(!blTest) return false;
		it2++;
	}
	return true;
}

//intersection
ints ints::operator*=(const ints& rhs)
{
	ints::iterator it=rhs.begin();
	ints::iterator itTemp;

	while(it!=end())
	{	if(rhs.find(*it)==rhs.end()) 
		{	ints::iterator itTemp=it;
			itTemp++;
			erase(*it);
			it=itTemp;
			continue;
		}
		it++;
	}
	return *this;
}


//union
ints ints::operator+=(const ints& rhs)//the Union
{
	ints::iterator it=rhs.begin();
	while(it!=rhs.end())
	{
		insert(*it);
		it++;
	}
	return *this;
}

ints ints::operator-=(const ints& rhs)
{
	ints::iterator it=rhs.begin();
	while(it!=rhs.end())
	{	erase(*it);	it++;}
	return *this;
}

//the set union
ints operator+(const ints& lhs, const ints& rhs)//the Union
{
	ints::iterator it=rhs.begin();
	ints isResult=lhs;
	while(it!=rhs.end())
	{
		isResult.insert(*it);
		it++;
	}
	return isResult;
}

//the set intersection
ints operator*(const ints& lhs, const ints& rhs)//the Intersection
{
	ints isResult;
	ints::iterator it=rhs.begin();

	while(it!=rhs.end())
	{	if(lhs.find(*it)!=lhs.end()) 
			isResult.insert(*it);
		it++;
	}
	return isResult;
}

ints operator-(const ints& lhs, const ints& rhs)
{
	ints::iterator it=rhs.begin();
	ints isResult=lhs;
	while(it!=rhs.end())
	{
		isResult.erase(*it);
		it++;
	}
	return isResult;
}

//creates the complete set on n elements (that is from 0 to n)


void ints::full(int n)
{	while(n)
	{	n--;
		insert(n);
	}
	insert(0);
}

ostream& operator<<(ostream&s,ints isSet)
{
	ints::iterator it=isSet.begin();
	s<<"#Elem="<<isSet.size()+"{";
	while(it!=isSet.end())
	{	s<<*it<<",";
		it++;
	}
	s<<"}";
	return s;
}
