/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   ParameterManager.h
 * Author: peter
 *
 * Created on 6. Oktober 2016, 17:26
 * 
 * This simple parameter manager assumes the following command arguments format:
 *    program -par1 value1 -par2 value2 fileName1 fileName2
 * 
 * Note that each parameter must have a value.
 * 
 */

#ifndef PARAMETERMANAGER_H
#define PARAMETERMANAGER_H

#include <iostream>
#include <map>
#include <vector>
#include <string>

class ParameterManager {
public:
    ParameterManager(int argc, char *argv[]);
    ParameterManager(const ParameterManager& orig);
    virtual ~ParameterManager();
    
    int get_int(std::string parName, int defaultVal);
    std::string get_string(std::string parName, std::string defaultVal);
    
    std::vector<std::string> fileNames(){
        return fileNames_;
    }
    
private:
    int argc_;
    char **argv_;
    std::map<std::string,std::string> parameters;
    std::vector<std::string> fileNames_;
};

#endif /* PARAMETERMANAGER_H */

