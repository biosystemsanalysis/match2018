// #include "StdAfx.h"

#define __AFXWIN_H__

#include <iostream>
#include <stdio.h>
#include <string>


