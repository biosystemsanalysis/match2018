#if !defined(__Chemistry)
#define __Chemistry

#include "stdlib.h"

#include <set>
#include <vector>
#include <string>
#include <iostream>
#include <fstream>

#include <string>
#include <map>

using namespace std ;

// ----------------------------------------------------------------------

class TheMolecules;
class StochMatrix;


// ----------------------------------------------------------------------
//      Molecule   (just a number)
// ----------------------------------------------------------------------
// Molecules are currently just numbers (integers greater or equal zero).
// There is a class "TheMolecules" that stores all information about
// all possible molecules. E.g. TheMolecules can return the name given
// the molcules number.
// ----------------------------------------------------------------------

typedef int Molecule;
#define NO_MOLECULE -1


// ----------------------------------------------------------------------
// Molecules  (a multi set of molecules)
// ----------------------------------------------------------------------
// A multi set of molecules is e.g. required to specify the left side 
// of a reaction equation. 
//
// ----------------------------------------------------------------------

class Molecules : public set< pair<int, Molecule> > {
public:
    void insert(int n, Molecule m); // adds n molecules of type m to the multiset
    void read_until(istream & is, string end_marker, TheMolecules *tm);
    void read_without_order_until(istream & is, string end_marker, TheMolecules *tm);
    void write(ostream &os, TheMolecules *theMolecules);
    set<Molecule> mkset();  // returns the set of molecules represented by the multi set
};

// ----------------------------------------------------------------------
// Reaction  (a single reaction rule)
// ----------------------------------------------------------------------
//   is a pair of Molecules for left and right side of the reaction rule
// ----------------------------------------------------------------------


class Reaction : public pair<Molecules, Molecules> {
 public:
    set<Molecule> productset();
    set<Molecule> eductset();

    set<Molecule> m_productset;
    set<Molecule> m_eductset;
    void init_m_productset_eductset(){  // call this whenever the reaction changes
        m_productset = productset();
        m_eductset = eductset();
    }

    
    
    bool isProduct(Molecule a); // returns true if a is a product of this reaction
    bool isEduct(Molecule a); // returns true if a is an educt of this reaction
  
    double rate(){return m_rate;} // returns the reaction rate
    bool  rate_defined(){return m_rate_defined;} // returns wheter the reaction rate is defined

    vector<string> info() {return m_info;} // returns additional information of this reaction
    
    void read(istream &is, TheMolecules *theMolecules);
    void read_without_order(istream &is, TheMolecules *theMolecules);
    void write(ostream &os, TheMolecules *theMolecules);

 private:
    double m_rate;
    bool m_rate_defined;
    vector<string> m_info;
    
};

// ------------------------------------------------------------
//     MoleculeInfo (all information about one molecule) 
// ------------------------------------------------------------

class MoleculeInfo{
public:
    int number;
    string name;
    void write(ostream & os){
	os << number << "\t" << name;
    }
};

// ------------------------------------------------------------
//     TheMolecules (information about all possible molecules)
// ------------------------------------------------------------


class TheMolecules : public vector<MoleculeInfo> {
public:
    string name(Molecule m);
    Molecule molecule(string name);
    Molecule insert(string name);

    set<string> set2names(set<Molecule> ms);

    set<string> set2names_python(set<Molecule> ms);
    

    bool checkbounds(Molecule m){
	return ((m >= 0) && (m < ((int)this->size())));
    }
    void write(ostream & os);

};

istream& operator>>(istream&s, TheMolecules  & tm);
ostream& operator<<(ostream&s, TheMolecules  & tm);



// ------------------------------------------------------------
//     TheReactions (list of all reactions)
// ------------------------------------------------------------

#define MAX_MOL 200
class TheReactions : public vector<Reaction> {
private:
    TheMolecules *theMolecules;
  bool reactionPath[MAX_MOL][MAX_MOL]; // stores whether there is a path from a to b;  needs to be made dynamic
public:
  int verbose;
  TheReactions() {
    verbose=0;
    // init reaction path matrix to false
    for(unsigned int i = 0;i< MAX_MOL;i++)
      for(unsigned int j = 0;j< MAX_MOL;j++)
	reactionPath[i][j] = false;
  }
  void setMolecules (TheMolecules *tm){
    theMolecules = tm;
  }
  set<Reaction> reactions(Molecules);
  
  void read(istream &is, TheMolecules *theMolecules);
  void write(ostream &os);
  
  void remove_self_replicators();
  void remove_reversible_reactions();

  // new: 16.03.2017
  bool reactionFromTo(Molecule a, Molecule b);
    // true if there is a reaction with a as a reactand and b as a product

  bool reactionPathFromTo(Molecule a, Molecule b);
    // true if there is a reaction path from  a to b
  void computeReactionPath();
  
  void printAllPaths(ostream & os);
  // print all a - > b such that there is a path from a to b
  
  // methods to create dynamics
  map<string, double> default_parameter();
  StochMatrix  make_stoch_matrix();
  void make_ode_octave(ostream & os) {
    make_ode_octave(os, default_parameter());
  }
  void make_ode_octave(ostream & os, map<string, double> par);
};

ostream & operator<<(ostream&os, TheReactions  & tm);


// ------------------------------------------------------------
//     TheDynamics
// ------------------------------------------------------------


class TheDynamics {
private:
    TheMolecules *theMolecules;
    TheMolecules *theReactions;

public:
    void state(Molecules);
    Molecules state();
    double time();
    void time(double t);
    void simulate_until(double t);
};


// ------------------------------------------------------------
//     Chemistry
// ------------------------------------------------------------

class Chemistry {
public:
    TheMolecules theMolecules; 
    TheReactions theReactions;
    TheDynamics  theDynamics;
    int verbose;

    Chemistry(); // create an empty chemistry
    Chemistry(string fileName); // read chemistry from .rea file
    Chemistry(int m); // create with m molecules and an empty set of reactions

    void write(ostream & os = cout);

    void add_random_reaction_a_b_TO_c(int n = 1);

    void remove_self_replicators(){
	theReactions.remove_self_replicators();
    }
    void remove_reversible_reactions(){
	theReactions.remove_reversible_reactions();
    }

    TheReactions & reactions(set<Molecule> A);
    string reactions_vcg(set<Molecule> A);
    string reactions_gml(set<Molecule> A);



};


// ----------------------------------------------------------------------
//       StochMatrix
// ----------------------------------------------------------------------

// A StochMatrix is simply a m x 2*n matrix
// sm[0..m-1][0..2n-1]
//  m: number of reactions
//  n: number of molecules

class StochMatrix : public vector<vector<int> > {
 public:
    StochMatrix(int noOfReactions, int numberOfMol);
};


#endif








