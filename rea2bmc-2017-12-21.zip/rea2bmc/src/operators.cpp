#include "operators.h"
#include "Chemistry.h"
#include <string>
#include <algorithm>


// ----------------------------------------------------------------------
// +  set<Molecule>
// ----------------------------------------------------------------------
// set union
// EXAMPLE:  A + B
// ----------------------------------------------------------------------


set<Molecule> operator+(const set<Molecule> A, const set<Molecule> B){
    set<Molecule> result;
    insert_iterator<set<Molecule> > ii(result, result.begin());
    set_union(A.begin(), A.end(),
                                B.begin(), B.end(),
                                ii);
    return result;
}


// ----------------------------------------------------------------------
// *  set<Molecule>
// ----------------------------------------------------------------------
// set intersection
// EXAMPLE:  A * B
// ----------------------------------------------------------------------


set<Molecule> operator*(const set<Molecule> A, const set<Molecule> B){
    set<Molecule> result;
    insert_iterator<set<Molecule> > ii(result, result.begin());
    set_intersection(A.begin(), A.end(),
                                B.begin(), B.end(),
                                ii);
    return result;
}

// ----------------------------------------------------------------------
// -  set<Molecule>
// ----------------------------------------------------------------------
// set minus
// EXAMPLE:  A - B
// ----------------------------------------------------------------------


set<Molecule> operator-(const set<Molecule> A, const set<Molecule> B){
    set<Molecule> result = A;
    set<Molecule>::iterator it = B.begin();
    while(it!=B.end()){
	result.erase(*it);
	it++;
    }
    return result;
}
 


// ----------------------------------------------------------------------
// +  set<set<Molecule> >
// ----------------------------------------------------------------------
// set of sets union
// EXAMPLE:  A + B
// ----------------------------------------------------------------------

set<set<Molecule> > operator+(const set<set<Molecule> > A, const set<set<Molecule> > B){
    set<set<Molecule> > result;
    insert_iterator<set<set<Molecule> > > ii(result, result.begin());
    set_union(A.begin(), A.end(),
                                B.begin(), B.end(),
                                ii);
    return result;
}


// ----------------------------------------------------------------------
// -  set<set<Molecule> >
// ----------------------------------------------------------------------
// set of sets minus
// EXAMPLE:  A - B
// ----------------------------------------------------------------------


set<set<Molecule> > operator-(const set<set<Molecule> > A, const set<set<Molecule> > B){
    set<set<Molecule> > result = A;
    set<set<Molecule> >::iterator it = B.begin();
    while(it!=B.end()){
	result.erase(*it);
	it++;
    }
    return result;
}
 



// ----------------------------------------------------------------------
//   output vector
// ----------------------------------------------------------------------


ostream& operator<<(ostream&s, vector<double> v)
{
	vector<double>::iterator it=v.begin();
	s << "(";
	while(it!=v.end())
	{	s << " " << *it ;
		it++;
	}
	s<<" )";
	return s;
}


ostream& operator<<(ostream&s, vector<int> v) 
{
    vector<int>::iterator it=v.begin();
    s << "(";
    while(it!=v.end()){	
	s << " " << *it ;
	it++;
    }
    s << " )";
    return s;
}

ostream& operator<<(ostream&s, vector<vector<int> > v) 
{
    vector<vector<int> >::iterator it=v.begin();
    s << "(";
    while(it!=v.end()){	
	s << " " << *it ;
	it++;
    }
    s << " )";
    return s;
}

ostream& operator<<(ostream&s, vector<set<int> > v) 
{
    vector<set<int> >::iterator it=v.begin();
    s << "(";
    while(it!=v.end()){	
	s << " " << *it ;
	it++;
    }
    s << " )";
    return s;
}


// ----------------------------------------------------------------------
//    output set
// ----------------------------------------------------------------------



ostream& operator<<(ostream&os, set<string> v)
{
	set<string>::iterator it=v.begin();
	os << "[";	
	while(it!=v.end()){
	    os << " " << (*it) ;
	    it++;
	}
	os << " ]";
	return os;
}


ostream& operator<<(ostream&s, set<int> v)
{
	set<int>::iterator it=v.begin();
	s << "[";
	while(it!=v.end())
	{	s << " " << *it ;
		it++;
	}
	s<<" ]";
	return s;
}

istream& operator>>(istream&s, set<int> & v){
    // clear the set v
    set<int> empty_set;   // CORRECTED 23.01.2004 !
    v = empty_set;

    string buf;
    s >> buf;  // read {
    s >> buf; 
	
    while(buf != "}"){
	v.insert(atoi(buf.c_str()));
	s >> buf;
    }
    return s;
}


ostream& operator<<(ostream&s, set<set<int> > isSet)
{
	set<set<int> >::iterator it=isSet.begin();
	s << "[";
	while(it!=isSet.end())
	{	s << " " << *it ;
		it++;
	}
	s<<" ]";
	return s;
}

ostream& operator<<(ostream&t, set<vector<double> > dsSet)
{
	set<vector<double> >::iterator it=dsSet.begin();
	t << "[";
	while(it!=dsSet.end())
	{	t << " " << *it ;
		it++;
	}
	t<<" ]";
	return t;
}


