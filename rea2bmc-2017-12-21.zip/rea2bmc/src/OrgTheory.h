#if !defined(__OrgTheory)
#define __OrgTheory

#include <set>
#include <vector>
#include <string>
#include <iostream>
#include <fstream>

#include <string>

#include "Chemistry.h"

using namespace std ;

#define FIND_ORG_ABOVE_MAX_DEPTH 100000
#define FIND_CLOSURE_ABOVE_MAX_DEPTH 100000


// ------------------------------------------------------------
//     OrgTheory
// ------------------------------------------------------------

class OrgTheory {
 public:
    Chemistry *chemistry;
    int verbose;

    OrgTheory(Chemistry & pChemistry);

    // functions for organization theory
    
    set<Molecule> generate(set<Molecule> A, set<Molecule>  input);
    set<Molecule> closure(set<Molecule> A, set<Molecule>  input);
    set<Molecule> closure(set<Molecule> A);
    set<Molecule> selfMantSubset(set<Molecule> A, set<Molecule>  input);
    set<Molecule> sqr(set<Molecule> A, set<Molecule>  input);
    set<Molecule> sqr(const set<Molecule> & A);
   

    // ______ functions that might take a lot of time _____________

    void generate_lattice(); // finds all organizations

    set< set<Molecule> > organizations(set<Molecule> A, set<Molecule> input);

    // ______ new functions that help to generate the lattice  _____________

    set< set<Molecule> > all_organizations(set<Molecule> A, 
						      set<Molecule> input);


    // find all organizations directly above O
    set< set<Molecule> > find_org_above(set<Molecule> O, 
						   set<Molecule> usable,
						   set<Molecule> input);
    // find all organizations that contain try_this directly above O     
    set< set<Molecule> > find_org_above(set<Molecule> O, 
						   set<Molecule> try_this,
						   set<Molecule> usable,
						   set<Molecule> input,
						   int depth);

  // ______ functions to find all closed sets  _____________

    set< set<Molecule> > all_closures(set<Molecule> A, 
						      set<Molecule> input);

        set< set<Molecule> > all_closures(set<Molecule> A, 
					  set<Molecule> input, int maxClosures);


    // find all closures directly above O
    set< set<Molecule> > find_closure_above(set<Molecule> O, 
						   set<Molecule> usable,
						   set<Molecule> input);

    // find all clsoures that contain try_this directly above O
    // (should be the closure of O union try_this)     
    set< set<Molecule> > find_clsoure_above(set<Molecule> O, 
						   set<Molecule> try_this,
						   set<Molecule> usable,
						   set<Molecule> input,
						   int depth);



   
 
    set<set<Molecule> > set_of_educts(set<Molecule> not_self_mant, 
				      set<Molecule> usable, 
				      set<Molecule> input);



    set<Molecule> maintained_molecules(set<Molecule> A, 
				       set<Molecule> input);

    
    set<set<Molecule> > minimal_sets_of_educts(set<Molecule> not_mant, 
					       set<Molecule> usable, 
					       set<Molecule> input );


    // helper methods for the new algorithm

    // find all reactions among usable+input that produce this molecule
    vector<Reaction> find_reactions(Molecule mol, 
				    set<Molecule> usable, 
				    set<Molecule> input);


};




#endif








