#if !defined(_FUN)
#define _FUN

// a collection of functions that can be usefull everywhere and
// that I do not like to assigne to a class, yet.

#include <string>
#include <map>
#include "Chemistry.h"

using namespace std;

#ifdef _MONITOR
#define _CC(name) fun::count_calls(name);
#define _CC_SETS(name, s) fun::count_sets(name, s);
#else
#define _CC(name) ;
#define _CC_SETS(name, s) ;
#endif



class fun {
 public:
    static string itos(int i);

    static bool contains(const set<Molecule> & A, const set<Molecule> & B);  // true iff A contains B
    static bool contains(const set<Molecule> & A, Molecule B);  // true iff A contains B
    static string space(int i);  // returns a blank string of length i


    static bool is_positive(const vector<int> & v); /* returns true if all
						       elements v[i] > 0 */
    static bool is_not_one(const vector<int> & v); /* returns true if all
						       elements v[i] != 1 */
    static bool all_elements_equal_to(
	const vector<int> & v,
	int k);                                /* returns true if all
						  elements v[i] == k */


    static int product(const vector<int> & v); /* returns the product of all components of v */

    // stuff to count the number of function calls
    // juse add something like _CC("nameofunction") to the function.

    static int count_calls(string name);
    static void count_calls_print(ostream & os);
    static map<string,int> counted_calls;

    static int count_sets(string name, const set<int> & s);
    static void count_sets_print(ostream & os);
    static map<string, set<set<int> > > counted_sets;

};



#endif
