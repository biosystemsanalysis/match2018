// RNG.h: interface for the rng class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_RNG_H__46F183C0_5F14_4F8C_BC8C_14D8B0EE7318__INCLUDED_)
#define AFX_RNG_H__46F183C0_5F14_4F8C_BC8C_14D8B0EE7318__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

class rng  
{
public:
	rng();
	virtual ~rng();
    static int randomSeed(int seed); // returns the seed (if seed==0, a seed will be generated)
    static int randomInt(int min, int max);
    static double randomReal(double min, double max);
    static double randomReal();


    // -------------------- rand2 -------------------------------------------------------- _______

    static long ran2();			// rand2 from numerical recipies
                                // returns a 31 bit random integer
    static void ran2Seed(long seed);	// seeds rand2
    static float ran2Float();

    static long idum[1];		// internal stuff for rand2
    static long idum2;
    static long iy;
    static long iv[32]; 

  // -----------------------------------------------------------------------------------_




};

#endif // !defined(AFX_RNG_H__46F183C0_5F14_4F8C_BC8C_14D8B0EE7318__INCLUDED_)
