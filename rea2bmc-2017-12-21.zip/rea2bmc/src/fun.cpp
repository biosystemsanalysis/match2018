// a collection of functions that can be usefull everywhere and
// that I do not like to assigne to a class, yet.

#include "fun.h"
#include "operators.h"

#include <stdio.h>

#include <algorithm>
#include <string>
#include <set>
#include <map>

using namespace std;


string fun::itos(int i){
    static char buf[200];
    sprintf(buf, "%d", i);
    return buf;
}



// ----------------------------------------------------------------------
// contains(A, B), true iff A contains B, i.e. B is a subset of A
// ----------------------------------------------------------------------
// new: 28.04.2017

bool fun::contains(const set<Molecule> & A, const set<Molecule> & B){
    if (B.size() > A.size())
        return false;
    set<Molecule>::iterator it;
    for(it = B.begin(); it != B.end(); it++)
      // if (! fun::contains(A, (*it)))
      if (A.find(*it) == A.end())
	return false;
    return true;
}


/*
// version before 28.04.2017
bool fun::contains(const set<Molecule> & A, const set<Molecule> & B){
    if (B.size() > A.size())
        return false;
    return ( (A * B) == B);   
}
*/

// ----------------------------------------------------------------------
// contains(A, B), true iff A contains B
// ----------------------------------------------------------------------

bool fun::contains(const set<Molecule> & A,Molecule B){
    // set<Molecule>::iterator it;
    // it = A.find(B);
    return (A.find(B) != A.end());  
}


// space: create a string of blanks of length i

string fun::space(int i){
    string a;
    while(i-- > 0)
	a = a + " ";
    return a;
}
    
// properties of integer vectors

bool  fun::is_positive(const vector<int> & v){ /* returns true if all
						       elements v[i] > 0 */
    uint i=0;
    for(i=0;i < v.size();i++)
	if (v[i] <= 0) return false;
    return true;
}


bool  fun::is_not_one(const vector<int> & v){ /* returns true if not all
						       elements v[i] == 1 */
    return (!all_elements_equal_to(v, 1));
}

bool  fun::all_elements_equal_to(
	const vector<int> & v,
	int k){                                /* returns true if all
						  elements v[i] == k */
    uint i=0;
    for(i=0;i < v.size();i++)
	if (v[i] != k) return false;
    return true;
}


int fun::product(const vector<int> & v){ /* returns the product of all components of v */
    int prod=1;
    uint i;
    for(i=0;i < v.size();i++)
	prod *= v[i];
    return prod;
}

// stuff to count function calls:

map<string,int> fun::counted_calls;

int fun::count_calls(string name){
    return counted_calls[name]++;
}
	

void fun::count_calls_print(ostream & os){
    map<string,int>::iterator it;
    for(it = counted_calls.begin(); it != counted_calls.end(); it++)
	os << (*it).first << "  \t" << (*it).second << "\n";
}


// count sets

int fun::count_sets(string name, const set<int> & s){
    counted_sets[name].insert(s);
    return counted_sets[name].size();
}

void fun::count_sets_print(ostream & os){
    map<string, set<set<int> > >::iterator it; 
    for(it = counted_sets.begin(); it != counted_sets.end(); it++)
    os << (*it).first << "  \t" << (*it).second.size() << "\n";
}

map<string, set<set<int> > > fun::counted_sets;
