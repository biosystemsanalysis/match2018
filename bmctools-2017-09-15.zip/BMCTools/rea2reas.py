# -*- coding: utf-8 -*-
# Version: 170912
#Author: Christoph Neu

"""Usage: sbml2reas.py (FILE) [-s int] [-t int] [-c int] [-d]

Arguments:
  FILE                      Required input *.rea file
  
Options:
  -h --help                 Show this (Version: 170912)
  -s <int>  Seed count      Number of Seeds (Default is 20000)
  -t <int>  Threshold       Upper Threshold for Subnetworks (Default is 27)(Sould be 17 without Inflow)
  -c <int>  Choice mode     Creates <int> groups of subnetworks, of which one can be chosen (Activates -d)(Default is 1)
  -d        Distribution    Show the distribution inside the Subnetworks (automatically on of choice mode is used)

"""
from docopt import docopt


arguments = docopt(__doc__)


#from libsbml import SBMLReader
import random
import os


import time

start_time = time.time()

#To run it without arguments from editor comment out above and uncomment next line
#arguments = {'-c': None, '-d': False, '-l': False, '-m': False, '-r': False, '-s': '100', 'FILE': '../../NetzwerkAuswertungen/iIT431/iIT341-20000b/iIT341.xml'}

overallPrint = []
def print_func(string):
	string = str(string)
	print string
	global overallPrint
	overallPrint.append(string)

print_func(arguments)


#xmlPath = r"/home/stud/other/vi46mas/Dokumente/Model/iAB_RBC_283.xml"

arguments["FILE"] = os.path.abspath(arguments["FILE"])
TargetPath = os.path.dirname(arguments["FILE"])
os.chdir(TargetPath)


if arguments["-c"] == None:
    repetitions = 1
else:
    repetitions = int(arguments["-c"])

if arguments["-s"] == None:
    Seeds = 20000
else:
    Seeds = int(arguments["-s"])

if arguments["-t"] == None:
    threshold = 27
else:
    threshold = int(arguments["-t"])



###################################Access SMBL File#############################    
#xmlPath = arguments["FILE"]
#reader = SBMLReader()
#document = reader.readSBML(xmlPath)
#model = document.getModel()



###################################Functions#############################    



def give_SpeciesDicFromRea(ReaPath):
    #get Dictionary of species
    ## It will create a dictionary of the Species ID as the key and the Species Nr. as the value
    ReaFile = open(ReaPath, 'r')
    ComponentLines = False
    ComponentCounter = -1
    SpeciesDic = {}
    for n in ReaFile:
        line = n[:-1]
        if ComponentLines == True and line[0]== "#":
            ComponentLines = False

        if ComponentLines == True:
            ComponentCounter += 1
            SpeciesDic[line.split("#")[0].strip()] = ComponentCounter

        if "# Components" in n or "#Components" in n:
            ComponentLines = True
            
    for specie in SpeciesDic.keys(): #Del species which only occure in beggining list, but not in the ReaDic Later on.
        if len((give_PreAndPostReaNr([specie], ReactionDic))[specie][1]) == 0:
            if len((give_PreAndPostReaNr([specie], ReactionDic))[specie][0]) == 0:
                del SpeciesDic[specie]


    ReaFile.close()
    
    return SpeciesDic


def give_ReactionDicFromRea(ReaPath):
    #get Dictionary of reactions from ReaFile 
    #Format {ReaNum:[Reactant,Product],...} and each reactant or Product in the Format {Name:Stoich,,,, }
    ReaFile = open(ReaPath, 'r')
    ReactionDic ={}
    ReactionLines = False
    ReactionCounter = -1
    for n in ReaFile:
        line = n[:-1]
        if ReactionLines == True and "#" in n:
            ReactionLines = False
        if ReactionLines == True:
            ReactionCounter += 1
            ListOfEducts = filter(None,line.split("->")[0].split(" "))
            ListOfProducts = filter(None,line.split("->")[1].split(" "))
            DicOfEducts = {}
            DictOfProducts = {}
            for index, value in enumerate(ListOfEducts):
                if not index % 2 == 0:
                    DicOfEducts[value] = int(float(ListOfEducts[index -1]))
            for index, value in enumerate(ListOfProducts):
                if not index % 2 == 0:
                    DictOfProducts[value] = int(float(ListOfProducts[index -1]))
            #print str(DicOfEducts) + " --> "+ str(DictOfProducts)
            ReactionDic[ReactionCounter] = [DicOfEducts,DictOfProducts]
        if "# Reactions" in n or "#Reactions" in n:
            ReactionLines = True

    ReaFile.close()            
    return ReactionDic


def give_SingleEntryList(list):
    #Takes list as an and Returns the same list without any duplicates
    #Note: Order of the Items are changed.
    list = sorted(list)
    TempList = []
    pre = ""
    for value in list:
        if value == pre:
            pass
        else:
            pre = value
            TempList.append(value)
    list = TempList
    return list

    
def give_PreAndPostReaNr(Species_List, dic):
    #which Reaction produces these onetime Reacted and which reactions consumes them
    ##Takes List of Species as input
    ##Format: {SpeciesID;[ReactionsID in which they are Products,Reaction ID in which they the reactant],...}
    PrePostSpecies_Dic = {}
    for Species in Species_List:

        ReactionNr_AsProduct = []
        ReactionNr_Asreactant = []
        for ReaNr in dic:
            for Product_n in dic[ReaNr][1]:
                if Species == Product_n:
                    ReactionNr_AsProduct.append(ReaNr)
                    break
                else:
                    pass
                
            for Reactant_n in dic[ReaNr][0]:
                if Species == Reactant_n:
                    ReactionNr_Asreactant.append(ReaNr)
                else:
                    pass
        PrePostSpecies_Dic[Species]= [ReactionNr_AsProduct,ReactionNr_Asreactant]
    return PrePostSpecies_Dic    


def give_ReaFile_2(ReaDic,filename): 
    # Write a rea file of the ReactionDic in the working dictionary, 
    # This Function is for the multiple rea file of the subnetworks and does not contain the long form because rea2iboc can not handle the comments.
    # I know having two functions is not the most elegant solution, but its an artifact of the merging of SBML2rea and rea2reas. 
    output = open(filename, 'w')
    
    #Write the Components in the File
    output.write("# Number of Components \n" )
    output.write(str(len(give_Specieslist(ReaDic))) +"\n" )
    output.write("# Components \n" )
    """
    MaxLength = 0 # Establish longer Component ID to align all Names
    for n in SpeciesDic:
        if MaxLength < len(n):
            MaxLength = len(n)
        else:
            pass
     """   
    for Id in give_Specieslist(ReaDic):
        output.write(str(Id)+"\n")
    
    #Write The reaction in the File    
    output.write("# Number of Reactions \n" )    
    output.write(str(len(ReaDic))+"\n" )    
    output.write("# Reactions \n" )  
    
    for keys in ReaDic:
        Reaction_str = ""
        for Reactan in ReaDic[keys][0]:
            Stoich =  ReaDic[keys][0][Reactan]
            Reaction_str  = Reaction_str + str(Stoich)+ " " + str(Reactan) + " "
        if Reaction_str[-3:] == " ":#Cuts the last + but not if there are no Reactant
            Reaction_str = Reaction_str[:-3]
        else: 
            pass 
        Reaction_str = Reaction_str  + " -> "
        for Product in ReaDic[keys][1]:
            Stoich =  ReaDic[keys][1][Product]
            Reaction_str  = Reaction_str + str(Stoich)+ " " + str(Product) + " "
        if Reaction_str[-3:] == " ": #Cuts the last + but not if there are no Products
            Reaction_str = Reaction_str[:-3]
        output.write(str(Reaction_str)+"\n")     
        
    output.close()
                
    return "File <" + str(filename) + "> successfully created"


def give_Closure(Species_List, ReactionDic):
    #Gives the closure of a List of Species
    #Input: The complet ReactionDic and a list of the Species
    #Output: A list of Species, which build up this closure.
    change = True
    counter = 0
    while change == True:
        counter += 1
        length = len(Species_List)

        for ReaNr in ReactionDic:
            if set(ReactionDic[ReaNr][0].keys()) <= set(Species_List):
                for Species in ReactionDic[ReaNr][1].keys():
                    if Species not in Species_List:
                        Species_List.append(Species)

        if length == len(Species_List):
            change = False
            #print "Done on "+str(counter)+ ". Iteration, with the final closure:"
            #print Species_List
            #print ""
        else:
            pass
            #print str(counter)+ ". Iteration done, --> "+ str(counter + 1) + ". is about to start"

    return Species_List
   

def print_Subnetworklength(ListOfSubNetworks):
    # Prints a table with the different lengths of closures and how often they occurs.
    print_func("")
    print_func("|Closure Length| Quantity in Nr |           Quantity in Percentage-Bars           | ")
    list = []
    for m in range(100):
        counter = 0
        for n in ListOfSubNetworks:
            if len(give_Specieslist(n)) == m:
                counter += 1
                if m == 1:
                    print_func(n)
        if counter > 0:
            list.append(counter)
    max_length = sorted(list)[-1]
    for m in range(100):
        counter = 0
        for n in ListOfSubNetworks:
            if len(give_Specieslist(n)) == m:
                counter += 1
                if m == 1:
                    print_func(n)
        if counter > 0:
            print_func(" "*7+ str(m).ljust(16) +str(counter).ljust(11)+str(((50*counter)//max_length + ((50*counter)%max_length > 0))*"#"))
    print_func("")


def give_SubNet(ListOfSubNetworks):
    # Gives a ReaDic for a given list of Species
    #Input: List of ListOfSpecies which are part of a subnetwork
    #Output: List of Reaction dictionaries of the Species 
    ListOfSub = []
    for SubIndex, SubNet in enumerate(ListOfSubNetworks):
        SubReactionDic = {}
        for ReaNr in ReactionDic:
            ListOfParticipants = ReactionDic[ReaNr][0].keys() +ReactionDic[ReaNr][1].keys()
            if set(ListOfParticipants) <= set(ListOfSubNetworks[SubIndex]):
                SubReactionDic[ReaNr] = ReactionDic[ReaNr]
        #print ListOfSubNetworks[SubIndex]
        ListOfSub.append(SubReactionDic)
    return ListOfSub


def give_Specieslist(ReaDic):
    #Returns a List of all Species of a given ReactionDic.
    ListOfSpecies = []
    for ReaNr in ReaDic:
        ListOfSpecies = ListOfSpecies + ReaDic[ReaNr][0].keys() + ReaDic[ReaNr][1].keys()
    ListOfSpecies = give_SingleEntryList(ListOfSpecies)
    return ListOfSpecies
    
    
def give_Subnetworks(ListOfSpecies, ReaDic,SeedNr):
    #Split a ReactionDic into multiple Subnetworks, of which each one is a closure.
    #Input: List of All Species and the ReactionDic and the SeedNr(Number of created Subnetworks).
    #Output:List of ReactionDic, with each Dic, as a Closure and a Subnetwork of the original network
    ## The closure must have at least 6 species
    ## It will try to return the biggest closure in a range between 6 and 16, if this is not possible
    ## the smallest closure above the size of 16 is returned.
    ## Duplication and smaller closures which are part of a bigger one are removed.
    """
    #Gives the List of 1000 (see range(1000)) closures below the size of 15
    1. Make a list of 1000 random Seeds from the ListOfSpecies
    2. For every seed/Closure choose the seed/or one Species of the closure randomly
    3. Of this Species choose one reaction where it participates randomly and add all its components
    4. Calculate the closure of of all components
    5. if size is 17 or above break and take original closure if the original closure is above 5 as subnetwork
           if it is below 8 take the smallest of the bigger closures.  
       else: make new closure to closure and goto 2
    """
    def give_SubnetworksUnchecked():
  
        def biasAddition():
            """Creat List of Reactions where their count is inversely proportional to the count of added species."""
            SpeciesCountList = []
            for Rea_temp in ListOfReactions:
                MemOfRea_temp = []
                for Product in ReaDic[Rea_temp][0]:
                    MemOfRea_temp.append(Product)
                for Educt in ReaDic[Rea_temp][1]:
                    MemOfRea_temp.append(Educt)
                SpeciesCountList.append(float(len(MemOfRea_temp)))
            
            SpeciesCountProz = []
            for SpeciesCount in SpeciesCountList:
                SpeciesCountProz.append(SpeciesCount/float(sum(SpeciesCountList)))
            
            InvSpeciesCount = []
            for SpeciesCount in SpeciesCountProz:
                InvSpeciesCount.append(1.0/(1.0+SpeciesCount))
            
            InvSpeciesCountProz = []
            for SpeciesCount in InvSpeciesCount:
                InvSpeciesCountProz.append(int(round((1000.0*(SpeciesCount/float(sum(InvSpeciesCount)))),0)))
            
            ListOfMultReactions = []
            for index, value in enumerate(ListOfReactions):
                for n in range(0,InvSpeciesCountProz[index]):
                    ListOfMultReactions.append(value)
            if len(ListOfMultReactions)-sum(InvSpeciesCountProz) != 0:
                print_func(len(ListOfMultReactions)-sum(InvSpeciesCountProz))
                
            return random.choice(ListOfMultReactions) 
            """------------------------------------------------------------------------------------------------"""
    
        ListOfSubNetworks = []
        ListOfSeeds = []
        for n in range(SeedNr):
            ListOfSeeds.append(random.choice(ListOfSpecies))
    
        for seed in ListOfSeeds:
            OldClosure = [seed]
            run = True
            FailSaveCounter =  0
            NewClosureSize = []

            while run == True:
                if FailSaveCounter == 0:
                    specie = random.choice(OldClosure)
    
                ListOfReactions = []
                for n in (give_PreAndPostReaNr([specie], ReaDic))[specie][0]:
                    ListOfReactions.append(n)
                for n in (give_PreAndPostReaNr([specie], ReaDic))[specie][1]:
                    ListOfReactions.append(n)
                    
                    
                #ReaNrX = biasAddition() # Choose from the Inversly proportional list of reactions
                ReaNrX = random.choice(ListOfReactions)#Choose just one Reaction, without a bias
    
                MemOfReaX = [] #Members of Reaaction X
                for Product in ReaDic[ReaNrX][0]:
                    MemOfReaX.append(Product)
                for Educt in ReaDic[ReaNrX][1]:
                    MemOfReaX.append(Educt)
    
                NewClosure = give_Closure(give_SingleEntryList((MemOfReaX+OldClosure)), ReaDic)
    
                FailSaveCounter += 1
    
    
    
                if len(NewClosure) < threshold:
                    if OldClosure == NewClosure and FailSaveCounter < 100:
                        specie = random.choice(OldClosure)
                    elif OldClosure == NewClosure and FailSaveCounter > 99:
                        run = False
                    else:
                        OldClosure = NewClosure
                        FailSaveCounter = 0
                        NewClosureSize = []
    
                else:
                    if len(OldClosure) > 5:
                        ListOfSubNetworks.append(OldClosure)
                        run = False
                    elif len(OldClosure) < 6 and FailSaveCounter < 50:
                        NewClosureSize.append(len(NewClosure))
                    elif len(OldClosure) < 6 and FailSaveCounter > 49:
                        if len(NewClosure) <= sorted(NewClosureSize)[0]:
                            ListOfSubNetworks.append(NewClosure)
                            run = False
                        else:
                            # Can not directly choose the smalest one because only the size is saved
                            #Tested whether this has an effect on runtime, and no not worth saving the complet lists
                            # because it nearly never happens
                            pass

        return ListOfSubNetworks
        
    
    def remove_duplications():
        #Remove duplicates from the ListOfSubNetworks
        run = True
    
        while run == True:
            run = False
            for outer_index, outer_value in enumerate(ListOfSubNetworks):
                for inner_index, inner_value in enumerate(ListOfSubNetworks):
                    if outer_value == inner_value and outer_index != inner_index:
                        del_index = inner_index
                        run = True
                        break
                if run == True:
                    break
            if run == True:
                del ListOfSubNetworks[del_index]
        return ListOfSubNetworks
        

    def remove_inclusions():
        #Delete small closures if there are part of a bigger one.
        """Old Version
        run = True
        while run == True:
            run = False
            for outer_index, outer_value in enumerate(ListOfSubNetworks):
                for inner_index, inner_value in enumerate(ListOfSubNetworks):
                    if len(inner_value) < len(outer_value):
                        if set(inner_value) <= set(outer_value):
                            del_index = inner_index
                            run = True
                            break
                if run == True:
                    break
            if run == True:
                del ListOfSubNetworks[del_index]
        """
        #TimeSaving Version
        delList = []
        for outer_index, outer_value in enumerate(ListOfSubNetworks):
                for inner_index, inner_value in enumerate(ListOfSubNetworks):
                    if len(inner_value) < len(outer_value):
                        if set(inner_value) <= set(outer_value):
                            delList.append(inner_index)
    
        delList = give_SingleEntryList(delList)
        delList = sorted(delList , reverse=True)
        for index in delList:
            del ListOfSubNetworks[index]
        
        return ListOfSubNetworks
        
        
    ####################Function Calls
    timeFor_a = time.time()
    ListOfSubNetworks = give_SubnetworksUnchecked()
    print_func("Length befor duplication removal:".ljust(40)+ str(len(ListOfSubNetworks)))
    BeforeDubRemoval_time =(time.time() - start_time), "     : Time After Creation Of Subnetworks and befor Duplicationremoval"
    timeFor_b = time.time()
    
    ListOfSubNetworks = remove_duplications()    
    print_func("Length after duplication removal: ".ljust(40) + str(len(ListOfSubNetworks)))
    BeforeSubsetCheck_time =(time.time() - start_time), "     : Time After Duplicationremoval and befor Check for Subsets of Subnetworks"
    
    timeA = time.time()
    ListOfSubNetworks = remove_inclusions()
    print_func("Length after merging: ".ljust(40)+ str(len(ListOfSubNetworks)))
    #print "____________________"
    #print "Time of forst for loope:  ", (timeFor_b-timeFor_a)
    #print "Time of sec while Loope: ", (time.time() - timeA)
    #print "----------------------"

    
    #print_Subnetworklength(ListOfSubNetworks)
    

    ListOfSubNetworks.sort(key=len)
    ListOfSubNetworks = give_SubNet(ListOfSubNetworks)


    return [ListOfSubNetworks,BeforeDubRemoval_time,BeforeSubsetCheck_time]


def select_Structure(ListOfSubNetworks):
    #Selects from a list of ReaDic which has the potential to contain an IBOC
    #Input: List of ReaDics
    #Output: A list with two entries
    #       1. List of ReaDic
    #       2- Dictionary where the key is ReaDicIndex from the List and the value a list in a list of the reaction fulfilling the 3 criteria
    NewListOfSubNetworks = []
    DicOfFoundStructures = {}


    for ReaDic in ListOfSubNetworks:
        ReaNrList =[[],[],[]]
        SubClosure = {}
        Krit1_Counter = 0
        Krit2_Counter = 0
        Krit3_Counter = 0
        ListOfSpecies = []

        for ReaNr in ReaDic:
            if len(ReaDic[ReaNr][0]) > 1 and len(ReaDic[ReaNr][1]) > 0:
                Krit1_Counter += 1
                ReaNrList[0].append(ReaNr)
                SubClosure[ReaNr] = ReaDic[ReaNr]
            ListOfSpecies = ListOfSpecies + ReaDic[ReaNr][0].keys() + ReaDic[ReaNr][1].keys()
    
    	"""
        SpeciesPrePost = give_PreAndPostReaNr(ListOfSpecies, SubClosure)
        for Species in SpeciesPrePost:
            if len(SpeciesPrePost[Species][1]) > 1:
                ReaNrList[1] = ReaNrList[1]+ SpeciesPrePost[Species][1]
                Krit2_Counter += 1
                
            if len(SpeciesPrePost[Species][0]) > 1:
                ReaNrList[2] = ReaNrList[2]+ SpeciesPrePost[Species][0]
                Krit3_Counter += 1
        """
        
                
        if Krit1_Counter > 3:
            DicOfFoundStructures[len(NewListOfSubNetworks)] = ReaNrList
            NewListOfSubNetworks.append(ReaDic)


    print_func("Length after Kriterien Search: ".ljust(40)+ str(len(NewListOfSubNetworks)))
  

    return [NewListOfSubNetworks, DicOfFoundStructures]


def give_StructureReduction(Selected_Structurs):
    # Removes Networks which have identical Reactions in there Structure 
    #Input: List of ReaDic and Dictionaries with the corresponding structure-ReactionNr. (see select_Structure)
    #Output: List of ReaDic.
    ListOfSubNetworks =Selected_Structurs[0]
    DicOfFoundStructures = Selected_Structurs[1]
    NewListOfSubNetworks=[]
    counter = 0
    for index_o, Sub_o in enumerate(ListOfSubNetworks):
        Found = False
        for index_i, Sub_i in enumerate(ListOfSubNetworks):
            if index_i != index_o:
                if set(DicOfFoundStructures[index_o][0]) <= set(DicOfFoundStructures[index_i][0]):
                    if set(DicOfFoundStructures[index_o][1]) <= set(DicOfFoundStructures[index_i][1]):
                        if set(DicOfFoundStructures[index_o][2]) <= set(DicOfFoundStructures[index_i][2]):
                            Found = True

        if Found == False:
            counter += 1
            NewListOfSubNetworks.append(ListOfSubNetworks[index_o])
    print_func("Length after Kriterien Selection: ".ljust(40)+ str(len(NewListOfSubNetworks)))
    return NewListOfSubNetworks

    
def SortDicBySpecienCount(ListOfSubNetworks):
    #takes a List of ReactionDic and returns the same List, but sorted by the number of the Species involved.
    SortedList = []
    for n in range(100):
        for ReaDic in ListOfSubNetworks:
            if len(give_Specieslist(ReaDic)) == n and ReaDic not in SortedList:
                SortedList.append(ReaDic)
    counter =0            
    for ReaDic in SortedList:
        counter += 1
        
    return SortedList
    
    
def ReaLoop(ListOfSub,postfix):
    #Input: List Of ReactionDic
    #Output: creating reafiles in the working dictionary next to the input file.
    os.chdir(os.path.split(os.path.abspath(ReaPath))[0])
    FileName = os.path.split(os.path.abspath(ReaPath))[1]
    FolderName = "Sub_"+str(FileName)+postfix
    if os.path.isdir(str(FolderName)) == False:
        os.system("mkdir "+str(FolderName))
        os.chdir(str(FolderName))
        outputName = FolderName
    else:
        Isdir = True
        counter = 0
        while Isdir == True:
            counter += 1
            if os.path.isdir(str(FolderName)+"_"+str(counter)) == False:
                os.system("mkdir "+str(FolderName)+"_"+str(counter))
                os.chdir(str(FolderName)+"_"+str(counter))
                outputName = str(FolderName)+"_"+str(counter)
                Isdir = False
  
    printOut = open("output_"+outputName, 'w')
    printOut.write(str("test")+"\n" ) 
    for n in overallPrint:
    	printOut.write(str(n)+"\n" ) 

    printOut.close()

    for SubIndex, SubReaDic in enumerate(ListOfSub):
        FileName = "Sub"+str(SubIndex)+".rea"
        give_ReaFile_2(SubReaDic,FileName)
            



###################################Function Calls To Create Subnetworks#############################   


ReaPath = arguments["FILE"]

ReactionDic = give_ReactionDicFromRea(ReaPath)

ListOfListOfSubNetworks = []
counter = 0
for n in range(repetitions):
    BeforeSubnetwork_time =(time.time() - start_time), "     : Time Befor Creation Of Subnetworks"
    print_func("")
    print_func("-----------------")
    print_func("Following Subnetworks with the Index: "+str(counter))
    counter += 1
    
    give_Subnetworks_output = give_Subnetworks(give_SpeciesDicFromRea(ReaPath).keys(),give_ReactionDicFromRea(ReaPath),Seeds)
    ListOfSubNetworks = give_Subnetworks_output[0]
    AfterSubNetwork_time =(time.time() - start_time), "     : Time After Subsets of Subnetworks and Before Structure Selection"
    
    Selected_Structurs =select_Structure(ListOfSubNetworks)
    AfterStructe_time = (time.time() - start_time), "     : Time After Structure Selection and Before StructureReduction"
    
    #ListOfSubNetworks = give_StructureReduction(Selected_Structurs)
    #AfterSelection = (time.time() - start_time), "     : Time After Structure Selection Before Final Creation of All ReaFiles"
    
    ListOfSubNetworks = SortDicBySpecienCount(Selected_Structurs[0])
    
    ListOfListOfSubNetworks.append(ListOfSubNetworks)
    
    if repetitions == 1:
        if arguments["-d"] == True:
            print_Subnetworklength(ListOfSubNetworks)
    else:
        print_Subnetworklength(ListOfSubNetworks)

if repetitions == 1:
    #if arguments["-d"] == True:
    ReaLoop(ListOfListOfSubNetworks[0],"")
else:
    while True:
        try:
            index = int(raw_input("Enter the Index of the subnetwork: "))
        except ValueError:
            print_func("Sorry, should have entered an integer!")
            continue
    
        if index < 0 or index >= len(ListOfListOfSubNetworks):
            print_func("Sorry, you have to chose one of the shown index numbers!")
        else:
            ReaLoop(ListOfListOfSubNetworks[index],"")
            break


print_func("")
print_func( "-----------------" )       
print_func( BeforeSubnetwork_time)
print_func( give_Subnetworks_output[1])
print_func( give_Subnetworks_output[2])
print_func( AfterSubNetwork_time)
print_func( AfterStructe_time)
#print AfterSelection
Endtime = (time.time() - start_time), "     : Time After All Preocesses"
print_func(Endtime)

#print overallPrint

#############################Unused Functions###########################
"""
def give_SpeciesDic(model):
    #get list of species
    ## It will create a list of the Species ID, to get the Name use .getName , but the ID is the one used in the reactions. 
    SpeciesDic = {}
    NumOfSpecies = int(str(model.getListOfSpecies()).split("[")[-1][:-2]) 
    for n in range(0,NumOfSpecies):
        ID = model.getListOfSpecies().get(n).getId()
        FullName = model.getListOfSpecies().get(n).getName()
        SpeciesDic[ID]=FullName
    return SpeciesDic
"""
"""
def give_ReactionDic(model):       
    #get Dictionary of reactions 
    #Format {ReaNum:[Reactant,Product],...} and each reactant or Product in the Format {Name:Stoich,,,, }
    ReactionDic = {} 
    NumOfReaction = int(str(model.getListOfReactions()).split("[")[-1][:-2]) 
    for Reaction_n in range(0,NumOfReaction):
        NumOfReactants_n = int(str(model.getListOfReactions().get(Reaction_n).getListOfReactants()).split("[")[-1][:-2])
        NumOfProducts_n = int(str(model.getListOfReactions().get(Reaction_n).getListOfProducts()).split("[")[-1][:-2])
        #print "Reaction Nr. "+str(Reaction_n)+ " hat " + str(NumOfProducts_n) +" Producte and "+str(NumOfReactants_n)+ " Educt"
         #get list of Species Names  and Stoichfactors of Reactants
        ReactionDic_Reactants = {}
        for Reactant_n in range(0,NumOfReactants_n):
            Reactant_Stoich = int(model.getListOfReactions().get(Reaction_n).getReactant(Reactant_n).getStoichiometry())
            Reactant_Name = model.getListOfReactions().get(Reaction_n).getReactant(Reactant_n).getSpecies()
            ReactionDic_Reactants[Reactant_Name] = Reactant_Stoich
            
        #get list of Species Names  and Stoiechfactors of Products
        ReactionDic_Products = {}
        for Product_n in range(0,NumOfProducts_n):
            Product_Stoich=int(model.getListOfReactions().get(Reaction_n).getProduct(Product_n).getStoichiometry())
            Product_Name  =model.getListOfReactions().get(Reaction_n).getProduct(Product_n).getSpecies()
            ReactionDic_Products[Product_Name] = Product_Stoich
        ReactionDic[Reaction_n]=[ReactionDic_Reactants,ReactionDic_Products]
    return ReactionDic
"""
"""
def give_CutSpeciesDic(ReactionDic, SpeciesDic):
    #Give a SpeciesDic based on the ReactionDic, so that removed Species are no longer included
    CutSpecicesDic = {}
    for ReaNr in ReactionDic:
        for Reactant in ReactionDic[ReaNr][0]:
            CutSpecicesDic[Reactant] = SpeciesDic[Reactant]
        for Product in ReactionDic[ReaNr][1]:
            CutSpecicesDic[Product] = SpeciesDic[Product]
    return CutSpecicesDic
"""
"""
def give_Pairs(dic):
    #Input is the ReactionDic
    #out a List:
    #1 Entry is a ReactionDic with all Species which only present in a defined pair of Species combined to one, in the Format: 1Species_and_2Species
    #2 Entry is the boolean Change which is either True (if Species have been grouped) or False (if Species have not been grouped)
    #Note: In the current Version the Stoich-Value of the newly combined species is not the sum of the pair, but only the value of one of them. 
    GroupeList = []
    SetOfSpecies_dic = {}
    SetOfSpecies = []
    for ReaNr in dic:
        ReactantGroupe = []
        ProductGroupe = []
        for n in dic[ReaNr][0]:
            ReactantGroupe.append(n)
            SetOfSpecies_dic[n] = True
        for n in dic[ReaNr][1]:
            ProductGroupe.append(n)
            SetOfSpecies_dic[n] = True
        if len(ReactantGroupe) > 1:
            GroupeList.append(ReactantGroupe)
        else:
            pass
        if len(ProductGroupe) > 1:
            GroupeList.append(ProductGroupe)
        else:
            pass
    for n in SetOfSpecies_dic:
        SetOfSpecies.append(n)
    
        
    ListOfAllPairs =[]
    for Species in SetOfSpecies:
        for groupe in GroupeList:
            if Species in groupe:
                for member in groupe:
                    if Species == member:
                        pass
                    else:
                        ListOfAllPairs.append([Species,member])
                    
            else:
                pass
    ListOfAllPairs = give_SingleEntryList(ListOfAllPairs)
        
    PairCheck = {}
    for pair in ListOfAllPairs:
        for group in GroupeList:
            if pair[0] in group:
                if pair[1] in group:
                    PairCheck[str(pair[0]+"_and_"+pair[1])] = True
                else:
                    PairCheck[str(pair[0]+"_and_"+pair[1])] = False
                    break
            else:
                PairCheck[str(pair[0]+"_and_"+pair[1])] = False
                pass

    ListOfRealPairs = []
    for n in PairCheck:
        if PairCheck[n] == True:
            ListOfRealPairs.append(n)
        else:
            pass

    TempList = []
    for RealPair in ListOfRealPairs:
        TempList.append(sorted(RealPair.split("_and_")))
    ListOfRealPairs = give_SingleEntryList(TempList)
    
    DicOfDeletion = {"Pair0":{"key":[],"species":[]},"Pair1":{"key":[],"species":[]}}
    for pair in ListOfRealPairs:
        for key in dic:
            if pair[0] in dic[key][0] and pair[1] in dic[key][0]:
                for species in dic[key][0]:
                    if species == pair[0]:
                        dic[key][0][str(pair[0])+"_and_"+str(pair[1])] = dic[key][0][species]
                        del dic[key][0][species]
                    elif species == pair[1]:
                        DicOfDeletion["Pair0"]["key"].append(key)
                        DicOfDeletion["Pair0"]["species"].append(species)
                    else:
                        pass
            elif pair[0] in dic[key][1] and pair[1] in dic[key][1]:
                for species in dic[key][1]:
                    if species == pair[0]:
                        dic[key][1][str(pair[0])+"_and_"+str(pair[1])] = dic[key][1][species]
                        del dic[key][1][species]
                    elif species == pair[1]:
                        DicOfDeletion["Pair1"]["key"].append(key)
                        DicOfDeletion["Pair1"]["species"].append(species)   
                    else:
                        pass
    for DeletionNr in range(0,len(DicOfDeletion["Pair0"]["key"])):
        del dic[DicOfDeletion["Pair0"]["key"][DeletionNr]][0][DicOfDeletion["Pair0"]["species"][DeletionNr]]       
    for DeletionNr in range(0,len(DicOfDeletion["Pair1"]["key"])):
        del dic[DicOfDeletion["Pair1"]["key"][DeletionNr]][1][DicOfDeletion["Pair1"]["species"][DeletionNr]]              
        
    if len(ListOfRealPairs) == 0:
        Change = False
        print ""
        print "None/No further pairs could be found."
    else:
        print ""
        print "These pairs have been found :"+ str(ListOfRealPairs)
        Change = True
        
    
    return [dic,Change]
"""
"""
def give_Groups(ReactionDic):
    #Finding Groups of Species with more then 2 members
    # By Iterating through the ReactionDic until no Further groups have been found  
    # Input is a ReactionDic
    # Returns A Reaction Dic where all Groups of Species combined in one new Species
    Change = True
    while Change == True:
        output = give_Pairs(ReactionDic)
        ReactionDic = output[0]
        Change = output[1]     
    return ReactionDic
"""
"""
def give_OneTimeReactans(iReactionDic):
    #Creates List with species which are only A reactant in one and only one reaction from the ReactionDic
    ListOfReactans = []
    BlackList = []
    for Rea in iReactionDic:
        for Species in iReactionDic[Rea][0]:
            if len(iReactionDic[Rea][0]) == 1:
                ListOfReactans.append(Species)
            elif len(iReactionDic[Rea][0]) >1:
                BlackList.append(Species)
            else:
                break
    OneTimeReactant_List = []
    for n in ListOfReactans:
        if ListOfReactans.count(n) == 1:
            OneTimeReactant_List.append(n)
        else:
            pass
    MinsBlack = []
    for n in OneTimeReactant_List:
        if n in BlackList:
            pass
        else:
            MinsBlack.append(n)
    for index,value in enumerate(OneTimeReactant_List):
        if value in BlackList:
            del OneTimeReactant_List[index]
    return MinsBlack
"""        
"""
def give_ShortReactionDic(iReactionDic_Cut):
    #Creating New Reaction_dic (same format as above)
    #but species Removed which are only one time reactend and have at least one reaction in which they are Products
    SkipCounter    = 0
    counter = 0
    iOneTimeReactant_List = [1,1,1]
    while len(iOneTimeReactant_List) > SkipCounter+1 and counter < 10000:
        counter +=1

        iOneTimeReactant_List = give_OneTimeReactans(iReactionDic_Cut)
        Species = iOneTimeReactant_List[SkipCounter]
        #PrePostSpecies_Dic = give_PreAndPostReaNr([Species])
        PrePostSpecies_Dic = give_PreAndPostReaNr([Species], iReactionDic_Cut)
        #PrePostSpecies_Dic = give_NewReaNr(PrePostSpecies_Dic, iReactionDic_Cut.keys())

        if len(PrePostSpecies_Dic[Species][0]) == 0:
            SkipCounter +=1
        else:
            pass

        delete = False
        for ReaNr_asProduct in PrePostSpecies_Dic[Species][0]:
            delete = True
            ######################################Neu
            ReactionDic_Reactants = {}
            ReactionDic_Product = {}
            Reactant_NameList = iReactionDic_Cut[ReaNr_asProduct][0]
            for Reactant_Name in Reactant_NameList.keys():
                Reactant_Stoich = iReactionDic_Cut[ReaNr_asProduct][0][Reactant_Name]
                ReactionDic_Reactants[Reactant_Name] = Reactant_Stoich
            Products_NameList = iReactionDic_Cut[PrePostSpecies_Dic[Species][1][0]][1]
            for Product_Name in Products_NameList:
                Product_Stoich = iReactionDic_Cut[PrePostSpecies_Dic[Species][1][0]][1][Product_Name]
                ReactionDic_Product[Product_Name] = Product_Stoich          

            for Product in iReactionDic_Cut[ReaNr_asProduct][1]:
                ReactionDic_Product[Product] = iReactionDic_Cut[ReaNr_asProduct][1][Product]
                
            iReactionDic_Cut[str(ReaNr_asProduct)+"and"+str(PrePostSpecies_Dic[Species][1][0])] = [ReactionDic_Reactants,ReactionDic_Product]

            '''
            ########################################                
            print "-------------------For Reaction "+str(ReaNr_asProduct)+" and "+str(PrePostSpecies_Dic[Species][1][0]) +" of Species "+str(Species)
            print "Das sind die Vorlaufer:" + str(ReactionDic_Reactants)
            print "Das sind die Resultate:" + str(ReactionDic_Product)
            #############################################
            '''
            
            del iReactionDic_Cut[ReaNr_asProduct]
        if delete == True:
            del iReactionDic_Cut[PrePostSpecies_Dic[Species][1][0]]
        else:
            pass
        
    return iReactionDic_Cut
"""
"""
def give_ReaFile(ReactionDic,SpeciesDic,filename):
    # Write a rea file of the ReactionDic in the working dictionary, 
    # This Function is for the first single Rea file, and contains also the long form, as a comment not only the ID
    counter = 0
    if filename in os.listdir(os.getcwd()):
        while filename in os.listdir(os.getcwd()):
            counter += 1
            filename = str(counter)+"_"+filename
        output = open(filename, 'w')
    else:
        output = open(filename, 'w')
    
    #Write the Components in the File
    output.write("# Number of Components \n" )
    output.write(str(len(SpeciesDic)) +"\n" )
    output.write("# Components \n" )
    
    MaxLength = 0 # Establish longer Component ID to align al Names
    for n in SpeciesDic:
        if MaxLength < len(n):
            MaxLength = len(n)
        else:
            pass
        
    for Id in SpeciesDic:
        SpaceLength = MaxLength-len(Id)
        output.write(str(Id)+" "*SpaceLength+"#"+str(SpeciesDic[Id])+"\n")
    
    #Write The reaction in the File    
    output.write("# Number of Reactions \n" )    
    output.write(str(len(ReactionDic))+"\n" )    
    output.write("# Reactions \n" )  
    
    for keys in ReactionDic:
        Reaction_str = ""
        for Reactan in ReactionDic[keys][0]:
            Stoich =  ReactionDic[keys][0][Reactan]
            Reaction_str  = Reaction_str + str(Stoich)+ " " + str(Reactan) + " "
        if Reaction_str[-3:] == " ":#Cuts the last + but not if there are no Reactants
            Reaction_str = Reaction_str[:-3]
        else: 
            pass 
        Reaction_str = Reaction_str  + " -> "
        for Product in ReactionDic[keys][1]:
            Stoich =  ReactionDic[keys][1][Product]
            Reaction_str  = Reaction_str + str(Stoich)+ " " + str(Product) + " "
        if Reaction_str[-3:] == " ": #Cuts the last + but not if there are no Products
            Reaction_str = Reaction_str[:-3]
        output.write(str(Reaction_str)+"\n")     
        
    output.close()
                
    return "File <" + str(filename) + "> successfully created"
"""
"""
###################################Function Calls to create primary ReaFile#############################    

print(time.time() - start_time), "     : Time befor Creation of Main ReaFile"
SpeciesDic = give_SpeciesDic(model)
ReactionDic = give_ReactionDic(model)
for n in ReactionDic:
    if len(ReactionDic[n][1]) == 0:
        print ""
        print n
        print repr(ReactionDic[n]   )


if arguments["-m"] == False:
    ReactionDic =  give_Groups(ReactionDic)
if arguments["-l"] == False:
    oldlength = len(ReactionDic)
    ReactionDic = give_ShortReactionDic(ReactionDic)
    SpeciesDic = give_CutSpeciesDic(ReactionDic, SpeciesDic)
    print ""
    print "The count of originally <"+str(oldlength)+ "> reactions could be reduced by <"+ str(oldlength - len(ReactionDic)) + ">, due to chain effects."
if arguments["-r"] == True:
    print ""
    for n in ReactionDic:
       print "Reaktion "+ str(n).ljust(15) + str(ReactionDic[n][0]).ljust(60) + "--> " + str(ReactionDic[n][1]) 

print ""


filename = str(document.getModel()).split(" ")[1] + ".rea"

counter = 0
while filename in os.listdir(os.getcwd()):
    counter += 1
    if str(counter)+"_"+str(filename) in os.listdir(os.getcwd()):
        pass
    else:
        filename = str(counter)+"_"+str(filename)
        break
                
print give_ReaFile(ReactionDic,SpeciesDic,filename)
    
print(time.time() - start_time), "     : Time After Creation of Main ReaFile"
"""
#############################Model and Runtime Check###########################
"""
def check():
    #Analysis function to check the Runtime of the primary creation of the rea file.
    import timeit
    reader = SBMLReader()
    filelist = []
    for file in os.listdir(r"/home/stud/other/vi46mas/Dokumente/Model"):
        if file.endswith(".xml"):
            filelist.append(file)
        else:
            pass
    print filelist
    for filename in filelist:
        xmlPath = r"/home/stud/other/vi46mas/Dokumente/Model/smal/"+filename
        document = reader.readSBML(xmlPath)
        model = document.getModel()
        start = timeit.default_timer()
        SpeciesDic = give_SpeciesDic(model)
        ReactionDic = give_ReactionDic(model)
        OSpecies = len(SpeciesDic)
        OReaction = len(ReactionDic)
        
        #ReactionDic =  give_Groups(ReactionDic)
        
        ReactionDic = give_ShortReactionDic(ReactionDic)
        stop = timeit.default_timer()
        
        LSpecies = len(SpeciesDic)
        LReaction = len(ReactionDic)
        print ""
        print str(filename) + " took "+ str(stop - start )
        print "Species: "+"Von "+ str(OSpecies) + " auf "+ str(LSpecies)
        print "Reactions: "+"Von "+ str(OReaction) + " auf "+ str(LReaction)
        
#check()
"""