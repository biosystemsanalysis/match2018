# -*- coding: utf-8 -*-
# Version: 170914
#Author: Christoph Neu

"""Usage: ibocs2iboc.py <REA> <SubFolder> [-t SubfolderTwo] [-d SubFolderThree]

Arguments:
  REA                     Required input Rea file (used for the creation of the subnetworks
  SubFolder               Required path of the folder containing the IBOCs
  -t SubfolderTwo         (optional) Required path of second folder containing the IBOCs
  -d SubFolderThree       (optional) Required path of third folder containing the IBOCs
  
Options:
  -h --help                 Show this
"""

from docopt import docopt


arguments = docopt(__doc__)
print arguments


import ast
import string
import os
import datetime
"""
#DateiName = "e_coli_core-b.rea"

#Folder = "/home/stud/other/vi46mas/Dokumente/Search/e-coli-core-b.rea"

#FolderPath = str(Folder)+"Sub_"+ str(DateiName)+"/"
FolderPath = "/home/stud/other/vi46mas/Dropbox/Uni Jena/3. semester/Vertiefungsmodul/testRuns/Sub_iIT341.rea/"

#ReaPath = Folder + DateiName
ReaPath = "/home/stud/other/vi46mas/Dropbox/Uni Jena/3. semester/Vertiefungsmodul/testRuns/iIT341.rea"


FileName = FolderPath.split("/")[-2].split(".")[0].split("_")[-1]
print FileName
"""

FolderPathList = [str(os.path.abspath(arguments["<SubFolder>"]))+"/"]
ReaPath = os.path.abspath(arguments["<REA>"])
FileName = arguments["<REA>"].split("/")[-1].split(".")[-2]


if arguments["-t"] != None:
    SecFolderPath = str(os.path.abspath(arguments["-t"]))+"/"
    FolderPathList.append(SecFolderPath)
if arguments["-d"] != None:
    ThrFolderPath = str(os.path.abspath(arguments["-d"]))+"/"
    FolderPathList.append(ThrFolderPath)

dirPath = os.path.dirname(ReaPath)
os.chdir(os.path.abspath(dirPath))
counter = 0
while True:
    counter += 1
    try:
        os.mkdir("BMC_Results_"+str(counter))
        os.chdir("BMC_Results_"+str(counter))
        break
    except:
        pass
    if counter > 1000:
        break

identifier = open("BMC_Analysis_identifier.txt", 'w')
identifier.write(str(datetime.datetime.now().date())+"\n")
identifier.write(str(datetime.datetime.now().time())+"\n")
identifier.write("\n")
identifier.write(str(arguments)+"\n" ) 
identifier.close()

def give_ReactionDic(ReaPath):
    #get Dictonary of reactions from ReaFile 
    #Format {ReacNum:[Reactant,Product],...} and each reactant or Product in the Format {Name:Stoich,,,, }
    ReaFile = open(ReaPath, 'r')
    ReactionDic ={}
    ReactionLines = False
    ReactionCounter = -1
    for n in ReaFile:
        line = n[:-1]
        if ReactionLines == True and "#" in n:
            ReactionLines = False
        if ReactionLines == True:
            ReactionCounter += 1
            ListOfEducts = filter(None,line.split("->")[0].split(" "))
            ListOfProducts = filter(None,line.split("->")[1].split(" "))
            DicOfEducts = {}
            DictOfProducts = {}
            for index, value in enumerate(ListOfEducts):
                if not index % 2 == 0:
                    DicOfEducts[value] = int(float(ListOfEducts[index -1]))
            for index, value in enumerate(ListOfProducts):
                if not index % 2 == 0:
                    DictOfProducts[value] = int(float(ListOfProducts[index -1]))
            #print str(DicOfEducts) + " --> "+ str(DictOfProducts)
            ReactionDic[ReactionCounter] = [DicOfEducts,DictOfProducts]
        if "# Reactions" in n or "#Reactions" in n:
            ReactionLines = True

    ReaFile.close()            
    return ReactionDic

def give_ListOfIbocs(FolderPathList,Analysis):
    #Inpute: Path of folder containing the Iboc Files and wheather the run schould be analysed
    #Output On list with the format [IbOC1,Iboc2,Iboc3.....]
    #iboc[0] = s1 , iboc[1] = s2, iboc[2] = c1 , iboc[3] =c2,iboc[4] = m1, iboc[5] = m2 zimelich sicher das das falsch is ss mm cc
    FileCounter = 0
    FoundIbocs = 0
    NoIbocsFound = 0
    CancelCounter = 0
    
    ListOfTrueIbocFiles = []
    for FolderPath in FolderPathList:
        ListOfAllIbocFiles = []
        for file in os.listdir(FolderPath):
            if file.endswith(".bmc"):
                FileCounter += 1
                ListOfAllIbocFiles.append(file)
        
        
        for n in ListOfAllIbocFiles:
            IbocFile = open(FolderPath+n, 'r')
            iboc = IbocFile.read()
            iboc = iboc.replace("\n", "")
            iboc = iboc.replace(r'" "', r'","')
            if iboc == "[ ]":
                NoIbocsFound += 1
            elif iboc =="" or iboc == " ":
                CancelCounter += 1
            else:
                FoundIbocs += 1
    
                #iboc =  iboc[:-2]+',["'+str(n)+'"]]]' # das ggf löschen
                
                iboc = ast.literal_eval(iboc)
                
                for x in iboc:
                    x.append('["'+str(n)+'"]')
    
                ListOfTrueIbocFiles = ListOfTrueIbocFiles + iboc 
            IbocFile.close()
    
    if Analysis == True:
        """
        analysis_output = open("Analysis_"+str(FileName)+".txt", "w")
        analysis_output.write("Analysis of file "+str(FolderPath)+"\n")
        analysis_output.write("Found Files:".ljust(40)+str(FileCounter)+"\n")
        analysis_output.write("IBOC containing Files:".ljust(40)+str(FoundIbocs)+"\n")
        analysis_output.write("Total Number of Found Ibocs: ".ljust(40)+str(len(ListOfTrueIbocFiles))+"\n")
        analysis_output.write("Not IBOC containing Files::".ljust(40)+str(NoIbocsFound)+"\n")
        analysis_output.write("Runs cancelt due to closere size:".ljust(40)+str(CancelCounter))
        analysis_output.close()
        """
        """
        print "Found Files:".ljust(40)+str(FileCounter)
        print "IBOC containing Files:".ljust(40)+str(FoundIbocs)
        print "Total Number of Found Ibocs: ".ljust(40)+str(len(ListOfTrueIbocFiles))
        print "Not IBOC containing Files::".ljust(40)+str(NoIbocsFound)
        print "Runs cancelt due to closere size:".ljust(40)+str(CancelCounter)
        """

        analysis_output = open("Analysis_"+str(FileName)+".txt", "w")
        global analysis_output
        analysis_output.write("Analysis of file "+str(FolderPath)+"\n")

        analysis_output.write("Total Number of Subnetworks:".ljust(50)+str(FileCounter)+"\n")
        analysis_output.write("Subnetworks without a BMC:".ljust(50)+str(NoIbocsFound)+"\n")
        analysis_output.write("Runs canceled due to closure size:".ljust(50)+str(CancelCounter)+"\n")
        analysis_output.write("Subnetworks with BMCs:".ljust(50)+str(FoundIbocs)+"\n")
        analysis_output.write("Total Number of found BMCs: ".ljust(50)+str(len(ListOfTrueIbocFiles))+"\n")

        #analysis_output.close()

        print "Total Number of Subnetworks:".ljust(50)+str(FileCounter)
        print "Subnetworks without a BMC:".ljust(50)+str(NoIbocsFound)
        print "Runs canceled due to closure size:".ljust(50)+str(CancelCounter)
        print "Subnetworks with BMCs:".ljust(50)+str(FoundIbocs)
        print "Total Number of found BMCs:".ljust(50)+str(len(ListOfTrueIbocFiles))
        
        
    return ListOfTrueIbocFiles
        
def print_ListOfIbocs(ListOfIbocs):
    #Print the List of IBOCS
    for n in ListOfIbocs:
        print str(n[0]).ljust(15) +str(n[1]).ljust(15) +str(n[2]).ljust(35) +str(n[3]).ljust(35) +str(n[4]).ljust(40)+str(n[5])

def give_Closure(Species_List, ReactionDic):
    #Gives the closure of a List of Species
    change = True
    counter = 0
    while change == True:
        counter += 1
        length = len(Species_List)

        for ReaNr in ReactionDic:
            if set(ReactionDic[ReaNr][0].keys()) <= set(Species_List):
                for Species in ReactionDic[ReaNr][1].keys():
                    if Species not in Species_List:
                        Species_List.append(Species)

        if length == len(Species_List):
            change = False
            #print "Done on "+str(counter)+ ". iteration, with the final closure:"
            #print Species_List
            #print ""
        else:
            pass
            #print str(counter)+ ". iteration done, --> "+ str(counter + 1) + ". is about to start"

    return Species_List

def give_SingleEntryList(list):
    #Takes list as an and Returns the same list without any duplicats
    #Note: Order of the Items are changed.
    list = sorted(list)
    TempList = []
    pre = ""
    for value in list:
        if value == pre:
            pass
        else:
            pre = value
            TempList.append(value)
    list = TempList
    return list
    
def give_AtopClousure(ListOfIbocs):
    # Removes redundant Ibocs witch are part of another one.
    # Input: List Of Ibocs with the format [IbOC1,Iboc2,Iboc3.....]; iboc[0] = s1 , iboc[1] = s2, iboc[2] = m1 , iboc[3] =m2,iboc[4] = c1, iboc[5] = c2
    # Outpiut: Same format, with reduced number
    
    Found = True
    while Found == True:
        del_list = []
        for outer in ListOfIbocs:
            S1_o = outer[0]
            S2_o = outer[1]
            M1_o = outer[2]
            M2_o = outer[3]
        
            for index, inner in enumerate(ListOfIbocs):
                S1_i = inner[0]
                S2_i = inner[1]
                M1_i = inner[2]
                M2_i = inner[3]
    
    
                if inner != outer:
        
                    if (set(S1_i ) <= set(S1_o) and set(S2_i ) <= set(S2_o)) or (set(S1_i ) <= set(S2_o) and set(S2_i ) <= set(S1_o)):

                        if set(M1_i ) <= set(M1_o) and set(M2_i ) <= set(M2_o):
                            del_list.append(index)
                        elif set(M2_i ) <= set(M1_o) and set(M1_i ) <= set(M2_o):
                            del_list.append(index)
                            

                        
            if len(del_list) > 0:
                del_list = give_SingleEntryList(del_list)
                    
                for n in range(len(del_list)-1,-1,-1):
                    del ListOfIbocs[del_list[n]]
                    Found = True
                break
            else:
                Found = False
        
    return ListOfIbocs    

def give_AtopClousure_old(ListOfIbocs):
    # Removes redundant Ibocs witch are part of another one.
    # Input: List Of Ibocs with the format [IbOC1,Iboc2,Iboc3.....]; iboc[0] = s1 , iboc[1] = s2, iboc[2] = m1 , iboc[3] =m2,iboc[4] = c1, iboc[5] = c2
    # Outpiut: Same format, with reduced number
    del_list = []
    for outer in ListOfIbocs:
        S1_o = outer[0]
        S2_o = outer[1]
        M1_o = outer[2]
        M2_o = outer[3]
        C1_o = outer[4]
        C2_o = outer[5]
    
        for index, inner in enumerate(ListOfIbocs):
            S1_i = inner[0]
            S2_i = inner[1]
            M1_i = inner[2]
            M2_i = inner[3]
            C1_i = inner[4]
            C2_i = inner[5]
    
            if set(S1_i ) <= set(S1_o) and set(S2_i ) <= set(S2_o):
                if set(M1_i ) <= set(M1_o) and set(M2_i ) <= set(M2_o):
                    if set(C1_i ) <= set(C1_o) and set(C2_i) <= set(C2_o):
                        if inner != outer:
                            del_list.append(index)
                elif set(M2_i ) <= set(M1_o) and set(M1_i ) <= set(M2_o):
                    if set(C2_i ) <= set(C1_o) and set(C1_i) <= set(C2_o):
                        if inner != outer:
                            del_list.append(index)
                    
    del_list = give_SingleEntryList(del_list)
    
    for n in range(len(del_list)-1,-1,-1):
         del ListOfIbocs[del_list[n]]

    return ListOfIbocs

def give_SubNet(ListOfSubNetworks, ReactionDic):
    #Input: List of ListOfSpecies which are part of a subnetwork
    #Output: List of Reaction dictionaries of the Species 
    ListOfSub = []
    for SubIndex, SubNet in enumerate(ListOfSubNetworks):
        SubReactionDic = {}
        for ReaNr in ReactionDic:
            ListOfParticipants = ReactionDic[ReaNr][0].keys()# +ReactionDic[ReaNr][1].keys()
            if set(ListOfParticipants) <= set(ListOfSubNetworks[SubIndex]):
                SubReactionDic[ReaNr] = ReactionDic[ReaNr]
        #print ListOfSubNetworks[SubIndex]
        ListOfSub.append(SubReactionDic)
    return ListOfSub

def give_ReaFile(ReaDic,filename):
    #Returns a Reafile for a given Reactiondic
    def give_Specieslist(ReaDic):
        ListOfSpecies = []
        for ReaNr in ReaDic:
            ListOfSpecies = ListOfSpecies + ReaDic[ReaNr][0].keys() + ReaDic[ReaNr][1].keys()
        return give_SingleEntryList(ListOfSpecies)
    output = open("IBOCsREA_"+str(filename)+".rea", 'w')
    
    #Write the Components in the File
    output.write("# Number of Components \n" )
    output.write(str(len(give_Specieslist(ReaDic))) +"\n" )
    output.write("# Components \n" )
    """
    MaxLength = 0 # Establish longes Componet ID to allign al Names
    for n in SpeciesDic:
        if MaxLength < len(n):
            MaxLength = len(n)
        else:
            pass
     """   
    for Id in give_Specieslist(ReaDic):
        output.write(str(Id)+"\n")
    
    #Write The reaction in the File    
    output.write("# Number of Reactions \n" )    
    output.write(str(len(ReaDic))+"\n" )    
    output.write("# Reactions \n" )  
    
    for keys in ReaDic:
        Reaction_str = ""
        for Reactan in ReaDic[keys][0]:
            Stoich =  ReaDic[keys][0][Reactan]
            Reaction_str  = Reaction_str + str(Stoich)+ " " + str(Reactan) + " "
        if Reaction_str[-3:] == " ":#Cuts the last + but not if there are no Reactans
            Reaction_str = Reaction_str[:-3]
        else: 
            pass 
        Reaction_str = Reaction_str  + " -> "
        for Product in ReaDic[keys][1]:
            Stoich =  ReaDic[keys][1][Product]
            Reaction_str  = Reaction_str + str(Stoich)+ " " + str(Product) + " "
        if Reaction_str[-3:] == " ": #Cuts the last + but not if there are no Products
            Reaction_str = Reaction_str[:-3]
        output.write(str(Reaction_str)+"\n")     
        
    output.close()
                
    return "File <" + str(filename) + "> successfully created"    

def letter_replacement(ListOfIbocs,ReaDic,SpeciesDic):
    #Replaces all Species IDs in the List of IBOCs and the ReaDic with letters
    # Idea: Simplifies to read an IBOC
    #Output is a lsit with two entries, THe ListOfIbocs and the ReactionDic
    letter_dic = open("LetterDic_"+str(FileName)+".csv", 'w')
    
    for iboc_index, Iboc in enumerate(ListOfIbocs):
        for index_groupe,Groupe in enumerate(Iboc):
            for index_specis,species in enumerate(Groupe):
                ListOfIbocs[iboc_index][index_groupe][index_specis] = SpeciesDic[species]
                letter_dic.write(str(SpeciesDic[species])+";"+str(species)+"\n")

    for ReaNr in ReaDic:
        for produkt in ReaDic[ReaNr][0].keys():
            if SpeciesDic[produkt] != produkt:
                ReaDic[ReaNr][0][SpeciesDic[produkt]] = ReaDic[ReaNr][0][produkt]
                del ReaDic[ReaNr][0][produkt]
        for edukt in ReaDic[ReaNr][1].keys():
            if SpeciesDic[edukt] != edukt:
                ReaDic[ReaNr][1][SpeciesDic[edukt]] = ReaDic[ReaNr][1][edukt]
                del ReaDic[ReaNr][1][edukt]

    """            
    for ReaNr in IBOC_rea:
        for produkt in IBOC_rea[ReaNr][0].keys():
            IBOC_rea[ReaNr][0][SpeciesDic[produkt]] = IBOC_rea[ReaNr][0][produkt]
            del IBOC_rea[ReaNr][0][produkt]
        for edukt in IBOC_rea[ReaNr][1].keys():
            IBOC_rea[ReaNr][1][SpeciesDic[edukt]] = IBOC_rea[ReaNr][1][edukt]
            del IBOC_rea[ReaNr][1][edukt]
    """

    letter_dic.close()   
    return [ListOfIbocs,ReaDic]   

def give_SpecicesDic(ReaDic, ListOfIbocs):
    # returns a list with two elements
    # A Dic with the Species and its Shortcut: first enry all sec entry only the ons included in the IBOC
    ListOfLetters = []
    for itera in range(25):
        for letter in string.uppercase:
            ListOfLetters.append(str(string.uppercase[itera]+str(letter)))
    
    SpeciesDic = {}
    IBOCSpeciesDic = {}
    counter = 0
    for IBOC in ListOfIbocs:
        for Groupe in IBOC:
            for Species in Groupe:
                SpeciesDic[Species] = ListOfLetters[counter]
                IBOCSpeciesDic[Species] = ListOfLetters[counter]
                counter += 1
    ListOfSpecies = []
    for ReaNr in ReaDic:
        for Educt in ReaDic[ReaNr][0].keys():
            if Educt not in ListOfSpecies:
                ListOfSpecies.append(Educt)
        for Product in ReaDic[ReaNr][1].keys():
            if Product not in ListOfSpecies:
                ListOfSpecies.append(Product)
    
    for Species in ListOfSpecies:
        if Species not in SpeciesDic.keys():
            SpeciesDic[Species] = Species


    return [SpeciesDic, IBOCSpeciesDic]

def give_csv(ListOfIbocs):
    #Creats a csv File next to the subnetworks, with all IBOCs form the ListOFIBOCs
    output = open("ListOfIBOCs_"+str(FileName)+".csv", 'w')
    print ""
    for n in ListOfIbocs:
        output.write(str(n[0])+";" +str(n[1])+";" +str(n[2])+";" +str(n[3])+";" +str(n[4])+";"+str(n[5])+";"+str(n[6])+ "\n" )
        #print str(n[0]).ljust(10) +str(n[1]).ljust(10) +str(n[2]).ljust(25) +str(n[3]).ljust(25) +str(n[4]).ljust(30)+str(n[5]).ljust(10)
    output.close()         

def give_ReaOfIboc(ListOfIbocs,ReaDic,FileName):
    #Gives an ReactionDic for all Species of an IBOC 
    ListOfSpecies=[]
    for IBOC in ListOfIbocs:
        for Set in IBOC:
            for Species in Set:
                if Species not in ListOfSpecies:
                    ListOfSpecies.append(Species)
    

    IBOC_rea = give_SubNet([ListOfSpecies], ReaDic)[0]
    return IBOC_rea


######################################################Function Calls######################################################


ReaDic =  give_ReactionDic(ReaPath)
ListOfIbocs = give_ListOfIbocs(FolderPathList,True)
ListOfIbocs = give_AtopClousure(ListOfIbocs)


analysis_output.write("Total Number of BMCs After Duplication-removal: ".ljust(50)+str(len(ListOfIbocs))+"\n")
analysis_output.close()
print "Total Number of BMCs After Duplication-removal: ".ljust(50)+str(len(ListOfIbocs))
#print ""

#SpeciesDic = give_SpecicesDic(ReaDic, ListOfIbocs)[0]

'''
LetterReplacmentList =letter_replacement(ListOfIbocs,ReaDic,SpeciesDic)

ListOfIbocs = LetterReplacmentList[0]

ReaDic = LetterReplacmentList[1]
"""
for ReaNr in ReaDic:
    print ""
    for educt in ReaDic[ReaNr][0].keys():
        print educt

"""
'''
IBOC_rea = give_ReaOfIboc(ListOfIbocs,ReaDic,FileName)

#print_ListOfIbocs(ListOfIbocs)

give_ReaFile(IBOC_rea,FileName)
give_csv(ListOfIbocs)

"""
print ""
Species_List = ["DA",           'BE', 'BF', 'BG', 'EI', 'BI', 'BJ'     ]
print Species_List
Closour_Species = give_Closure(Species_List, ReaDic)
print Closour_Species
CloReaDic = give_SubNet([Closour_Species],ReaDic)
print ""
for index,Rea in enumerate(CloReaDic):
    for Reanr in Rea:
        print ""
        print str(Reanr).ljust(5) + str(CloReaDic[index][Reanr])
"""
